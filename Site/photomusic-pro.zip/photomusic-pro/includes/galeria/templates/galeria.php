<?php
// includes/galeria/templates/galeria.php

if (!defined('ABSPATH')) exit;

/**
 * Variáveis disponíveis:
 * $evento_nome
 * $evento_data
 * $slug
 * $id_evento
 * $id_aceite
 * $aceite_nome (adicionado no controller)
 */
?>

<style>
    .pm-galeria-container {
        max-width: 1100px;
        margin: 0 auto;
        padding: 20px;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }

    .pm-galeria-header {
        text-align: center;
        margin-bottom: 25px;
    }

    .pm-galeria-header h1 {
        font-size: 1.8rem;
        margin-bottom: 5px;
    }

    .pm-galeria-header p {
        font-size: 1rem;
        color: #555;
    }

    .pm-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
        gap: 12px;
    }

    .pm-item {
        position: relative;
        overflow: hidden;
        border-radius: 6px;
        cursor: pointer;
        background: #f3f3f3;
    }

    .pm-item img {
        width: 100%;
        height: 180px;
        object-fit: cover;
        transition: transform .3s ease;
    }

    .pm-item:hover img {
        transform: scale(1.05);
    }

    .pm-modal-bg {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.85);
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }

    .pm-modal-bg.active {
        display: flex;
    }

    .pm-modal-content img {
        max-width: 90vw;
        max-height: 90vh;
        border-radius: 8px;
    }

    .pm-close {
        position: absolute;
        top: 20px;
        right: 30px;
        font-size: 2rem;
        color: #fff;
        cursor: pointer;
    }
</style>

<div class="pm-galeria-container">

    <div class="pm-galeria-header">
        <h1><?php echo esc_html($evento_nome); ?></h1>
        <p><?php echo esc_html(date('d/m/Y', strtotime($evento_data))); ?></p>

        <?php if (!empty($aceite_nome)): ?>
            <p style="font-size:0.9rem;color:#777;">
                Acesso autorizado para: <strong><?php echo esc_html($aceite_nome); ?></strong>
            </p>
        <?php endif; ?>
    </div>

    <div class="pm-grid" id="pm-grid">
        <p>Carregando fotos...</p>
    </div>
</div>

<!-- MODAL -->
<div class="pm-modal-bg" id="pm-modal">
    <span class="pm-close" id="pm-close">&times;</span>
    <div class="pm-modal-content">
        <img id="pm-modal-img" src="" alt="Foto ampliada">
    </div>
</div>

<script>
(function() {

    const grid = document.getElementById("pm-grid");
    const modal = document.getElementById("pm-modal");
    const modalImg = document.getElementById("pm-modal-img");
    const closeBtn = document.getElementById("pm-close");

    // ============================================
    // 1. Carregar fotos (mock temporário)
    // ============================================
    // Aqui você vai integrar com Fotoshare, Nextcloud, S3 ou pasta protegida.
    // Por enquanto, vamos simular algumas imagens.

    const fotos = [
        "https://via.placeholder.com/800x600?text=Foto+1",
        "https://via.placeholder.com/800x600?text=Foto+2",
        "https://via.placeholder.com/800x600?text=Foto+3",
        "https://via.placeholder.com/800x600?text=Foto+4",
        "https://via.placeholder.com/800x600?text=Foto+5"
    ];

    grid.innerHTML = "";

    fotos.forEach(src => {
        const div = document.createElement("div");
        div.className = "pm-item";

        const img = document.createElement("img");
        img.src = src;
        img.alt = "Foto do evento";

        img.addEventListener("click", () => {
            modalImg.src = src;
            modal.classList.add("active");
        });

        div.appendChild(img);
        grid.appendChild(div);
    });

    // ============================================
    // 2. Fechar modal
    // ============================================
    closeBtn.addEventListener("click", () => {
        modal.classList.remove("active");
    });

    modal.addEventListener("click", (e) => {
        if (e.target === modal) modal.classList.remove("active");
    });

})();
</script>
