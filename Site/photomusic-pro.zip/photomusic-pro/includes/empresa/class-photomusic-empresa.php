<?php
// includes/empresa/class-photomusic-empresa.php

if (!defined('ABSPATH')) exit;

class PhotoMusic_Empresa {

    const OPTION_KEY = 'photomusic_empresa_dados';

    /* ============================================================
       INICIALIZA O PAINEL
       ============================================================ */
    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
    }

    /* ============================================================
       ADICIONA MENU NO ADMIN
       ============================================================ */
    public static function menu() {

        add_submenu_page(
            'photomusic-eventos',                     // menu pai
            'Dados da Empresa',               // título da página
            'Dados da Empresa',               // nome no menu
            'pm_gerenciar_usuarios',                 // permissão
            'photomusic_empresa',             // slug
            [__CLASS__, 'render_page']        // callback
        );
    }

    /* ============================================================
       REGISTRA CONFIGURAÇÕES
       ============================================================ */
    public static function register_settings() {

        register_setting(
            'photomusic_empresa_group',
            self::OPTION_KEY,
            [__CLASS__, 'sanitize']
        );
    }

    /* ============================================================
       SANITIZA OS DADOS
       ============================================================ */
    public static function sanitize($input) {

        $output = [];

        $output['nome_fantasia'] = sanitize_text_field($input['nome_fantasia'] ?? '');
        $output['razao_social']  = sanitize_text_field($input['razao_social'] ?? '');
        $output['cnpj']          = sanitize_text_field($input['cnpj'] ?? '');
        $output['telefone']      = sanitize_text_field($input['telefone'] ?? '');
        $output['email']         = sanitize_email($input['email'] ?? '');
        $output['site']          = esc_url_raw($input['site'] ?? '');
        $output['endereco']      = sanitize_textarea_field($input['endereco'] ?? '');
        $output['logo']          = esc_url_raw($input['logo'] ?? '');

        return $output;
    }

    /* ============================================================
       OBTÉM OS DADOS DA EMPRESA
       ============================================================ */
    public static function get() {
        return get_option(self::OPTION_KEY, []);
    }

    /* ============================================================
       RENDERIZA A PÁGINA DO PAINEL
       ============================================================ */
    public static function render_page() {

        $dados = self::get();
        ?>

        <div class="wrap">
            <h1>Dados da Empresa</h1>

            <form method="post" action="options.php">
                <?php settings_fields('photomusic_empresa_group'); ?>

                <table class="form-table">

                    <tr>
                        <th><label>Nome Fantasia</label></th>
                        <td><input type="text" name="<?php echo self::OPTION_KEY; ?>[nome_fantasia]"
                                   value="<?php echo esc_attr($dados['nome_fantasia'] ?? ''); ?>"
                                   class="regular-text"></td>
                    </tr>

                    <tr>
                        <th><label>Razão Social</label></th>
                        <td><input type="text" name="<?php echo self::OPTION_KEY; ?>[razao_social]"
                                   value="<?php echo esc_attr($dados['razao_social'] ?? ''); ?>"
                                   class="regular-text"></td>
                    </tr>

                    <tr>
                        <th><label>CNPJ</label></th>
                        <td><input type="text" name="<?php echo self::OPTION_KEY; ?>[cnpj]"
                                   value="<?php echo esc_attr($dados['cnpj'] ?? ''); ?>"
                                   class="regular-text"></td>
                    </tr>

                    <tr>
                        <th><label>Telefone</label></th>
                        <td><input type="text" name="<?php echo self::OPTION_KEY; ?>[telefone]"
                                   value="<?php echo esc_attr($dados['telefone'] ?? ''); ?>"
                                   class="regular-text"></td>
                    </tr>

                    <tr>
                        <th><label>E-mail</label></th>
                        <td><input type="email" name="<?php echo self::OPTION_KEY; ?>[email]"
                                   value="<?php echo esc_attr($dados['email'] ?? ''); ?>"
                                   class="regular-text"></td>
                    </tr>

                    <tr>
                        <th><label>Site</label></th>
                        <td><input type="url" name="<?php echo self::OPTION_KEY; ?>[site]"
                                   value="<?php echo esc_attr($dados['site'] ?? ''); ?>"
                                   class="regular-text"></td>
                    </tr>

                    <tr>
                        <th><label>Endereço Completo</label></th>
                        <td>
                            <textarea name="<?php echo self::OPTION_KEY; ?>[endereco]"
                                      rows="3" class="large-text"><?php
                                echo esc_textarea($dados['endereco'] ?? '');
                            ?></textarea>
                        </td>
                    </tr>

                    <tr>
                        <th><label>Logo da Empresa (URL)</label></th>
                        <td>
                            <input type="url" name="<?php echo self::OPTION_KEY; ?>[logo]"
                                   value="<?php echo esc_attr($dados['logo'] ?? ''); ?>"
                                   class="regular-text">
                            <p class="description">Cole aqui a URL da logo (use a biblioteca de mídia).</p>
                        </td>
                    </tr>

                </table>

                <?php submit_button(); ?>
            </form>
        </div>

        <?php
    }
}
