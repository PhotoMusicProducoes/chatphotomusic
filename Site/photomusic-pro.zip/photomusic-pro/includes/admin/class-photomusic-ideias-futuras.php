<?php
// includes/admin/class-photomusic-ideias-futuras.php

if (!defined('ABSPATH')) exit;

class PhotoMusic_Ideias_Futuras {

    const CAP_VIEW   = 'pm_ideias_view';
    const CAP_EDIT   = 'pm_ideias_edit';
    const TABLE_NAME = 'pm_ideias_futuras';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'register_menu']);
        add_action('admin_post_pm_salvar_ideia', [__CLASS__, 'handle_form']);
    }

    /**
     * Registra submenu em PhotoMusic → Ideias Futuras
     */
    public static function register_menu() {

        if (!current_user_can(self::CAP_VIEW)) {
            return;
        }

        add_submenu_page(
            'photomusic-eventos',                 // ou outro slug principal
            'Ideias Futuras',
            'Ideias Futuras',
            self::CAP_VIEW,
            'photomusic-ideias-futuras',
            [__CLASS__, 'render_page']
        );
    }

    /**
     * Página principal: lista + formulário (modo simples)
     */
    public static function render_page() {
        if (!current_user_can(self::CAP_VIEW)) {
            wp_die('Acesso negado.');
        }

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;

        $acao   = isset($_GET['acao']) ? sanitize_text_field($_GET['acao']) : '';
        $id     = isset($_GET['id']) ? intval($_GET['id']) : 0;
        $ideia  = null;

        if ($acao === 'editar' && $id > 0) {
            $ideia = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id));
        }

        $ideias = $wpdb->get_results("SELECT * FROM {$table} ORDER BY prioridade DESC, data_criacao DESC");

        ?>
        <div class="wrap">
            <h1>Ideias Futuras</h1>
            <p>Registro interno de ideias para evolução do ecossistema PhotoMusic.</p>
            <hr>

            <h2>Lista de ideias</h2>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Categoria</th>
                        <th>Prioridade</th>
                        <th>Status</th>
                        <th>Autor</th>
                        <th>Criada em</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($ideias): ?>
                    <?php foreach ($ideias as $row): ?>
                        <tr>
                            <td><?php echo esc_html($row->id); ?></td>
                            <td><?php echo esc_html($row->titulo); ?></td>
                            <td><?php echo esc_html($row->categoria); ?></td>
                            <td><?php echo esc_html($row->prioridade); ?></td>
                            <td><?php echo esc_html($row->status); ?></td>
                            <td><?php echo esc_html(self::get_autor_nome($row->autor_id)); ?></td>
                            <td><?php echo esc_html($row->data_criacao); ?></td>
                            <td>
                                <?php if (current_user_can('pm_ideias_edit')): ?>
                                    <a href="<?php echo esc_url(add_query_arg([
                                        'page' => 'photomusic-ideias-futuras',
                                        'acao' => 'editar',
                                        'id'   => $row->id
                                    ], admin_url('admin.php'))); ?>">
                                        Editar
                                    </a>
                                <?php endif; ?>

                                <?php if (current_user_can('pm_projetos_criar')): ?>
                                    |
                                    <a href="<?php echo esc_url(
                                        wp_nonce_url(
                                            admin_url('admin-post.php?action=pm_transformar_em_projeto&id=' . $row->id),
                                            'pm_transformar_em_projeto'
                                        )
                                    ); ?>">
                                        Transformar em Projeto
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="8">Nenhuma ideia cadastrada.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>

            <?php if (current_user_can(self::CAP_EDIT)): ?>
                <hr>
                <h2><?php echo $ideia ? 'Editar ideia' : 'Nova ideia'; ?></h2>

                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <?php wp_nonce_field('pm_salvar_ideia', 'pm_ideia_nonce'); ?>
                    <input type="hidden" name="action" value="pm_salvar_ideia">
                    <input type="hidden" name="id" value="<?php echo $ideia ? intval($ideia->id) : 0; ?>">

                    <table class="form-table">
                        <tr>
                            <th><label for="pm-titulo">Título</label></th>
                            <td>
                                <input type="text" id="pm-titulo" name="titulo" class="regular-text"
                                       value="<?php echo $ideia ? esc_attr($ideia->titulo) : ''; ?>" required>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="pm-descricao">Descrição</label></th>
                            <td>
                                <textarea id="pm-descricao" name="descricao" rows="6" class="large-text" required><?php
                                    echo $ideia ? esc_textarea($ideia->descricao) : '';
                                ?></textarea>
                                <p class="description">Você pode descrever a ideia em detalhes. Markdown simples é aceito.</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="pm-categoria">Categoria</label></th>
                            <td>
                                <input type="text" id="pm-categoria" name="categoria" class="regular-text"
                                       value="<?php echo $ideia ? esc_attr($ideia->categoria) : ''; ?>"
                                       placeholder="Ex: app, galeria, contratos, ia">
                            </td>
                        </tr>
                        <tr>
                            <th><label for="pm-prioridade">Prioridade</label></th>
                            <td>
                                <select id="pm-prioridade" name="prioridade">
                                    <?php
                                    $prioridade = $ideia ? intval($ideia->prioridade) : 1;
                                    ?>
                                    <option value="1" <?php selected($prioridade, 1); ?>>Baixa</option>
                                    <option value="2" <?php selected($prioridade, 2); ?>>Média</option>
                                    <option value="3" <?php selected($prioridade, 3); ?>>Alta</option>
                                    <option value="4" <?php selected($prioridade, 4); ?>>Crítica</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="pm-status">Status</label></th>
                            <td>
                                <?php $status = $ideia ? $ideia->status : 'rascunho'; ?>
                                <select id="pm-status" name="status">
                                    <option value="rascunho" <?php selected($status, 'rascunho'); ?>>Rascunho</option>
                                    <option value="planejada" <?php selected($status, 'planejada'); ?>>Planejada</option>
                                    <option value="em_andamento" <?php selected($status, 'em_andamento'); ?>>Em andamento</option>
                                    <option value="implementada" <?php selected($status, 'implementada'); ?>>Implementada</option>
                                    <option value="descartada" <?php selected($status, 'descartada'); ?>>Descartada</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="pm-sigilosa">Sigilosa</label></th>
                            <td>
                                <?php $sigilosa = $ideia ? intval($ideia->sigilosa) : 0; ?>
                                <label>
                                    <input type="checkbox" id="pm-sigilosa" name="sigilosa" value="1" <?php checked($sigilosa, 1); ?>>
                                    Esta ideia é sigilosa (visível apenas para perfis autorizados).
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="pm-tags">Tags</label></th>
                            <td>
                                <input type="text" id="pm-tags" name="tags" class="regular-text"
                                       value="<?php echo $ideia ? esc_attr($ideia->tags) : ''; ?>"
                                       placeholder="Ex: app, mobile, ia, galeria">
                            </td>
                        </tr>
                    </table>

                    <?php submit_button($ideia ? 'Atualizar ideia' : 'Salvar ideia'); ?>
                </form>
            <?php endif; ?>

        </div>
        <?php
    }

    /**
     * Processa criação/edição de ideia
     */
    public static function handle_form() {
        if (!current_user_can(self::CAP_EDIT)) {
            wp_die('Acesso negado.');
        }

        if (!isset($_POST['pm_ideia_nonce']) || !wp_verify_nonce($_POST['pm_ideia_nonce'], 'pm_salvar_ideia')) {
            wp_die('Nonce inválido.');
        }

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;

        $id         = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $titulo     = isset($_POST['titulo']) ? sanitize_text_field($_POST['titulo']) : '';
        $descricao  = isset($_POST['descricao']) ? wp_kses_post($_POST['descricao']) : '';
        $categoria  = isset($_POST['categoria']) ? sanitize_text_field($_POST['categoria']) : '';
        $prioridade = isset($_POST['prioridade']) ? intval($_POST['prioridade']) : 1;
        $status     = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'rascunho';
        $sigilosa   = isset($_POST['sigilosa']) ? 1 : 0;
        $tags       = isset($_POST['tags']) ? sanitize_text_field($_POST['tags']) : '';
        $autor_id   = get_current_user_id();
        $agora      = current_time('mysql');

        $data = [
            'titulo'         => $titulo,
            'descricao'      => $descricao,
            'categoria'      => $categoria,
            'prioridade'     => $prioridade,
            'status'         => $status,
            'sigilosa'       => $sigilosa,
            'tags'           => $tags,
            'data_atualizacao' => $agora,
        ];

        if ($id > 0) {
            $wpdb->update($table, $data, ['id' => $id]);
        } else {
            $data['autor_id']     = $autor_id;
            $data['data_criacao'] = $agora;
            $wpdb->insert($table, $data);
        }

        wp_redirect(add_query_arg(['page' => 'photomusic-ideias-futuras'], admin_url('admin.php')));
        exit;
    }

    /**
     * Helper para exibir nome do autor
     */
    private static function get_autor_nome($user_id) {
        $user = get_user_by('id', $user_id);
        return $user ? $user->display_name : 'Desconhecido';
    }
}
