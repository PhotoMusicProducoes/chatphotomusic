<?php
// includes/contratos/class-photomusic-clausulas.php

if (!defined('ABSPATH')) {
    exit;
}

class PhotoMusic_Clausulas
{
    public static function init()
    {
        add_action('admin_menu', [__CLASS__, 'register_menu']);
        add_action('admin_init', [__CLASS__, 'handle_form_submit']);
    }

    /**
     * Registra submenu para gerenciamento de cláusulas
     */
    public static function register_menu()
    {
        if (!PhotoMusic_Users::is_admin()) {
            return;
        }

        add_submenu_page(
            'photomusic-eventos',
            'Contratos - Cláusulas',
            'Cláusulas',
            'pm_gerenciar_usuarios',
            'photomusic-clausulas',
            [__CLASS__, 'render_page']
        );
    }

    /**
     * Nome da tabela de cláusulas
     */
    protected static function get_table()
    {
        global $wpdb;
        return $wpdb->prefix . 'pm_clausulas';
    }

    /**
     * Lista cláusulas com filtros simples
     */
    public static function get_clausulas($args = [])
    {
        global $wpdb;
        $table = self::get_table();

        $where  = 'WHERE 1=1';
        $params = [];

        if (!empty($args['tipo'])) {
            $where   .= ' AND tipo = %s';
            $params[] = $args['tipo'];
        }

        if (!empty($args['categoria'])) {
            $where   .= ' AND categoria = %s';
            $params[] = $args['categoria'];
        }

        if (isset($args['ativo']) && $args['ativo'] !== '') {
            $where   .= ' AND ativo = %d';
            $params[] = intval($args['ativo']);
        }

        $order_by = 'ordem ASC, id DESC';
        $sql      = "SELECT * FROM $table $where ORDER BY $order_by";

        if (!empty($params)) {
            return $wpdb->get_results($wpdb->prepare($sql, $params));
        }

        return $wpdb->get_results($sql);
    }

    /**
     * Carrega uma cláusula específica
     */
    public static function get_clausula($id)
    {
        global $wpdb;
        $table = self::get_table();

        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table WHERE id = %d", intval($id))
        );
    }

    /**
     * Cria ou atualiza uma cláusula
     */
    public static function save_clausula($data)
    {
        global $wpdb;
        $table = self::get_table();

        $id = isset($data['id']) ? intval($data['id']) : 0;

        $fields = [
            'titulo'     => sanitize_text_field($data['titulo'] ?? ''),
            'tipo'       => sanitize_text_field($data['tipo'] ?? 'geral'),
            'categoria'  => sanitize_text_field($data['categoria'] ?? 'ambos'),
            'tags'       => sanitize_text_field($data['tags'] ?? ''),
            'texto'      => wp_kses_post($data['texto'] ?? ''),
            'ordem'      => intval($data['ordem'] ?? 0),
            'ativo'      => isset($data['ativo']) ? 1 : 0,
            'updated_at' => current_time('mysql'),
        ];

        if ($id > 0) {
            $wpdb->update($table, $fields, ['id' => $id]);
            return $id;
        }

        $fields['created_at'] = current_time('mysql');
        $wpdb->insert($table, $fields);
        return $wpdb->insert_id;
    }

    /**
     * Soft delete: desativa a cláusula
     */
    public static function deactivate_clausula($id)
    {
        global $wpdb;
        $table = self::get_table();

        return $wpdb->update(
            $table,
            ['ativo' => 0, 'updated_at' => current_time('mysql')],
            ['id' => intval($id)]
        );
    }

    /**
     * Processa envio de formulário (criação/edição/desativação)
     */
    public static function handle_form_submit()
    {
        if (empty($_POST['pm_clausula_action'])) {
            return;
        }

        if (!current_user_can('pm_gerenciar_usuarios')) {
            return;
        }

        if (empty($_POST['pm_clausula_nonce']) ||
            !wp_verify_nonce($_POST['pm_clausula_nonce'], 'pm_clausula_form')) {
            return;
        }

        $action = sanitize_text_field($_POST['pm_clausula_action']);

        if ($action === 'save') {
            $data = [
                'id'        => $_POST['id'] ?? 0,
                'titulo'    => $_POST['titulo'] ?? '',
                'tipo'      => $_POST['tipo'] ?? 'geral',
                'categoria' => $_POST['categoria'] ?? 'ambos',
                'tags'      => $_POST['tags'] ?? '',
                'texto'     => $_POST['texto'] ?? '',
                'ordem'     => $_POST['ordem'] ?? 0,
                'ativo'     => isset($_POST['ativo']) ? 1 : 0,
            ];

            $id = self::save_clausula($data);

            PhotoMusic_Logs::add(
                'clausula_save',
                null,
                null,
                $id,
                'Cláusula salva/atualizada pelo painel.'
            );

            wp_redirect(add_query_arg([
                'page'    => 'photomusic-clausulas',
                'updated' => 1,
                'edit'    => $id,
            ], admin_url('admin.php')));
            exit;
        }

        if ($action === 'deactivate' && !empty($_POST['id'])) {
            $id = intval($_POST['id']);
            self::deactivate_clausula($id);

            PhotoMusic_Logs::add(
                'clausula_deactivate',
                null,
                null,
                $id,
                'Cláusula desativada pelo painel.'
            );

            wp_redirect(add_query_arg([
                'page'    => 'photomusic-clausulas',
                'updated' => 1,
            ], admin_url('admin.php')));
            exit;
        }
    }

    /**
     * Página de gerenciamento de cláusulas
     */
    public static function render_page()
    {
        if (!current_user_can('pm_gerenciar_usuarios')) {
            wp_die('Acesso negado.');
        }

        $editing_id = isset($_GET['edit']) ? intval($_GET['edit']) : 0;
        $editing    = $editing_id ? self::get_clausula($editing_id) : null;

        $tipos = [
            'geral'             => 'Geral',
            'pagamento'         => 'Pagamento',
            'servico'           => 'Serviço',
            'responsabilidade'  => 'Responsabilidade',
            'cancelamento'      => 'Cancelamento',
            'direitos_imagem'   => 'Direitos de Imagem',
            'logistica'         => 'Logística',
        ];

        $categorias = [
            'pf'    => 'Pessoa Física',
            'pj'    => 'Pessoa Jurídica',
            'ambos' => 'Ambos',
        ];

        $clausulas = self::get_clausulas();
        ?>
        <div class="wrap">
            <h1>Contratos - Cláusulas</h1>

            <?php if (!empty($_GET['updated'])): ?>
                <div class="notice notice-success is-dismissible">
                    <p>Cláusula salva com sucesso.</p>
                </div>
            <?php endif; ?>

            <div style="display:flex; gap:30px; align-items:flex-start;">

                <div style="flex:1;">
                    <h2><?php echo $editing ? 'Editar Cláusula' : 'Nova Cláusula'; ?></h2>

                    <form method="post">
                        <?php wp_nonce_field('pm_clausula_form', 'pm_clausula_nonce'); ?>
                        <input type="hidden" name="pm_clausula_action" value="save">
                        <input type="hidden" name="id" value="<?php echo esc_attr($editing->id ?? 0); ?>">

                        <table class="form-table">
                            <tr>
                                <th><label for="titulo">Título</label></th>
                                <td>
                                    <input type="text" name="titulo" id="titulo" class="regular-text"
                                           value="<?php echo esc_attr($editing->titulo ?? ''); ?>" required>
                                </td>
                            </tr>

                            <tr>
                                <th><label for="tipo">Tipo</label></th>
                                <td>
                                    <select name="tipo" id="tipo">
                                        <?php foreach ($tipos as $k => $v): ?>
                                            <option value="<?php echo esc_attr($k); ?>"
                                                <?php selected($editing->tipo ?? 'geral', $k); ?>>
                                                <?php echo esc_html($v); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <th><label for="categoria">Categoria</label></th>
                                <td>
                                    <select name="categoria" id="categoria">
                                        <?php foreach ($categorias as $k => $v): ?>
                                            <option value="<?php echo esc_attr($k); ?>"
                                                <?php selected($editing->categoria ?? 'ambos', $k); ?>>
                                                <?php echo esc_html($v); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>

                            <tr>
                                <th><label for="tags">Tags (serviços, contexto)</label></th>
                                <td>
                                    <input type="text" name="tags" id="tags" class="regular-text"
                                           placeholder="Ex: foto cabine, dj, corporativo"
                                           value="<?php echo esc_attr($editing->tags ?? ''); ?>">
                                    <p class="description">
                                        Use vírgulas para separar tags. Ex: casamento, corporativo, foto cabine.
                                    </p>
                                </td>
                            </tr>

                            <tr>
                                <th><label for="ordem">Ordem</label></th>
                                <td>
                                    <input type="number" name="ordem" id="ordem" class="small-text"
                                           value="<?php echo esc_attr($editing->ordem ?? 0); ?>">
                                    <p class="description">Define a ordem em que a cláusula aparece no contrato.</p>
                                </td>
                            </tr>

                            <tr>
                                <th><label for="texto">Texto da Cláusula</label></th>
                                <td>
                                    <?php
                                    $content   = $editing->texto ?? '';
                                    $editor_id = 'texto';
                                    $settings  = [
                                        'textarea_name' => 'texto',
                                        'textarea_rows' => 10,
                                        'media_buttons' => false,
                                    ];
                                    wp_editor($content, $editor_id, $settings);
                                    ?>
                                    <p class="description">
                                        Você pode usar variáveis como: {nome_cliente}, {documento_cliente},
                                        {data_evento}, {local_evento}, {lista_servicos}, {valor_total_final}.
                                    </p>
                                </td>
                            </tr>

                            <tr>
                                <th><label for="ativo">Ativa</label></th>
                                <td>
                                    <label>
                                        <input type="checkbox" name="ativo" id="ativo"
                                            <?php checked($editing->ativo ?? 1, 1); ?>>
                                        Cláusula ativa
                                    </label>
                                </td>
                            </tr>
                        </table>

                        <?php submit_button($editing ? 'Salvar Cláusula' : 'Criar Cláusula'); ?>
                    </form>
                </div>

                <div style="flex:1;">
                    <h2>Cláusulas Cadastradas</h2>

                    <?php if (empty($clausulas)): ?>
                        <p>Nenhuma cláusula cadastrada ainda.</p>
                    <?php else: ?>
                        <table class="widefat striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Título</th>
                                <th>Tipo</th>
                                <th>Categoria</th>
                                <th>Ativa</th>
                                <th>Ordem</th>
                                <th>Ações</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($clausulas as $c): ?>
                                <tr>
                                    <td><?php echo esc_html($c->id); ?></td>
                                    <td><?php echo esc_html($c->titulo); ?></td>
                                    <td><?php echo esc_html($tipos[$c->tipo] ?? $c->tipo); ?></td>
                                    <td><?php echo esc_html($categorias[$c->categoria] ?? $c->categoria); ?></td>
                                    <td><?php echo $c->ativo ? 'Sim' : 'Não'; ?></td>
                                    <td><?php echo esc_html($c->ordem); ?></td>
                                    <td>
                                        <a href="<?php echo esc_url(add_query_arg([
                                            'page' => 'photomusic-clausulas',
                                            'edit' => $c->id,
                                        ], admin_url('admin.php'))); ?>">
                                            Editar
                                        </a>

                                        <?php if ($c->ativo): ?>
                                            |
                                            <form method="post" style="display:inline;"
                                                  onsubmit="return confirm('Desativar esta cláusula?');">
                                                <?php wp_nonce_field('pm_clausula_form', 'pm_clausula_nonce'); ?>
                                                <input type="hidden" name="pm_clausula_action" value="deactivate">
                                                <input type="hidden" name="id" value="<?php echo esc_attr($c->id); ?>">
                                                <button type="submit" class="link-button" style="color:#a00;">
                                                    Desativar
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

            </div>
        </div>
        <style>
            .link-button {
                background:none;
                border:none;
                padding:0;
                margin:0;
                cursor:pointer;
            }
        </style>
        <?php
    }

    public static function gerar_contrato_html($evento, $contratante, $servicos, $financeiro)
    {
        $html = '';

        /*
        |--------------------------------------------------------------------------
        | 1. Preparar TAGS
        |--------------------------------------------------------------------------
        */
        $tags = [];

        if (!empty($evento['tipo'])) {
            $tags[] = sanitize_title($evento['tipo']);
        }

        foreach ($servicos as $s) {
            if (!empty($s['slug'])) {
                $tags[] = sanitize_title($s['slug']);
            }
            if (!empty($s['subtipo'])) {
                $tags[] = sanitize_title($s['subtipo']);
            }
            if (!empty($s['pacote'])) {
                $tags[] = sanitize_title($s['pacote']);
            }
        }

        /*
        |--------------------------------------------------------------------------
        | 2. Buscar cláusulas por tags e categoria PF/PJ
        |--------------------------------------------------------------------------
        */
        $categoria_contratante = $contratante['categoria'] ?? 'pf';
        $clausulas = self::buscar_por_tags($tags, $categoria_contratante);

        usort($clausulas, function ($a, $b) {
            return $a->ordem <=> $b->ordem;
        });

        /*
        |--------------------------------------------------------------------------
        | 3. Variáveis globais
        |--------------------------------------------------------------------------
        */
        $vars = [
            '{nome_cliente}'      => esc_html($contratante['nome'] ?? ''),
            '{documento_cliente}' => esc_html($contratante['documento'] ?? ''),
            '{email_cliente}'     => esc_html($contratante['email'] ?? ''),
            '{telefone_cliente}'  => esc_html($contratante['telefone'] ?? ''),
            '{endereco_cliente}'  => esc_html($contratante['endereco'] ?? ''),

            '{data_evento}'    => esc_html($evento['data'] ?? ''),
            '{horario_evento}' => esc_html($evento['horario'] ?? ''),
            '{local_evento}'   => esc_html($evento['local'] ?? ''),
            '{horas_evento}'   => esc_html($evento['horas'] ?? ''),

            '{deslocamento}' => esc_html($financeiro['deslocamento'] ?? ''),
            '{deslocamento_valor}' => ($financeiro['deslocamento_valor'] ?? 0) > 0
                ? 'R$ ' . number_format($financeiro['deslocamento_valor'], 2, ',', '.')
                : 'Grátis',

            '{desconto_manual}' => isset($financeiro['desconto_manual'])
                ? 'R$ ' . number_format($financeiro['desconto_manual'], 2, ',', '.')
                : 'R$ 0,00',

            '{valor_total_final}' => isset($financeiro['valor_total_final'])
                ? 'R$ ' . number_format($financeiro['valor_total_final'], 2, ',', '.')
                : 'R$ 0,00',
        ];

        /*
        |--------------------------------------------------------------------------
        | 4. Variáveis por serviço
        |--------------------------------------------------------------------------
        */
        $lista_servicos_html = '';

        foreach ($servicos as $index => $s) {
            $id = $index + 1;

            $nome   = $s['nome'] ?? '';
            $sub    = $s['subtipo'] ?? '';
            $pacote = $s['pacote'] ?? '';

            $vars["{servico_{$id}_nome}"]              = esc_html($nome);
            $vars["{servico_{$id}_subtipo}"]           = esc_html($sub);
            $vars["{servico_{$id}_pacote}"]            = esc_html($pacote);
            $vars["{servico_{$id}_quantidade_fotos}"]  = esc_html($s['quantidade_fotos'] ?? '');
            $vars["{servico_{$id}_horas}"]             = esc_html($s['horas_contratadas'] ?? '');
            $vars["{servico_{$id}_horas_minimas}"]     = esc_html($s['horas_minimas'] ?? '');
            $vars["{servico_{$id}_horas_maximas}"]     = esc_html($s['horas_maximas'] ?? '');

            $vars["{servico_{$id}_preco}"] = isset($s['preco_total'])
                ? 'R$ ' . number_format($s['preco_total'], 2, ',', '.')
                : 'R$ 0,00';

            $linha = '<p><strong>' . esc_html($nome) . '</strong>';

            if (!empty($sub)) {
                $linha .= ' – ' . esc_html($sub);
            }

            if (!empty($pacote)) {
                $linha .= ' – Pacote: ' . esc_html($pacote);
            }

            if (!empty($s['quantidade_fotos'])) {
                $linha .= ' – ' . esc_html($s['quantidade_fotos']) . ' fotos';
            }

            if (!empty($s['horas_contratadas'])) {
                $linha .= ' – ' . esc_html($s['horas_contratadas']) . ' horas';
            }

            $linha .= '</p>';

            $lista_servicos_html .= $linha;
        }

        $vars['{lista_servicos}'] = $lista_servicos_html;

        /*
        |--------------------------------------------------------------------------
        | 5. Montar HTML final
        |--------------------------------------------------------------------------
        */
        foreach ($clausulas as $c) {
            $texto = str_replace(
                array_keys($vars),
                array_values($vars),
                $c->texto
            );

            $html .= '<h3>' . esc_html($c->titulo) . "</h3>\n<p>{$texto}</p>\n";
        }

        /*
        |--------------------------------------------------------------------------
        | 6. Retornar contrato final
        |--------------------------------------------------------------------------
        */
        return "<div class='contrato-gerado'>{$html}</div>";
    }

    public static function buscar_por_tags($tags = [], $categoria = 'pf')
    {
        global $wpdb;

        $tabela = self::get_table();

        if (!is_array($tags)) {
            $tags = [$tags];
        }

        $tags = array_filter(array_map('sanitize_title', $tags));

        $condicoes_tags = [];
        foreach ($tags as $tag) {
            $condicoes_tags[] = $wpdb->prepare("FIND_IN_SET(%s, tags)", $tag);
        }

        $where_tags = count($condicoes_tags) > 0
            ? '(' . implode(' OR ', $condicoes_tags) . ')'
            : '1=1';

        $where_categoria = $wpdb->prepare(
            "(categoria = %s OR categoria = 'ambos')",
            $categoria
        );

        $query = "
            SELECT *
            FROM {$tabela}
            WHERE ativo = 1
            AND {$where_categoria}
            AND {$where_tags}
            ORDER BY ordem ASC, id DESC
        ";

        return $wpdb->get_results($query);
    }

}
