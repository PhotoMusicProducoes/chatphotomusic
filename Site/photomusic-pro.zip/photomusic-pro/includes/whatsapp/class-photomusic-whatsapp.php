<?php
// includes/whatsapp/class-photomusic-whatsapp.php

if (!defined('ABSPATH')) exit;

class PhotoMusic_WhatsApp {

    /**
     * Envia mensagem via provedor configurado
     */
    public static function send($telefone, $mensagem, $extra = []) {

        $telefone = preg_replace('/\D/', '', $telefone);
        $mensagem = wp_kses_post($mensagem);

        if (empty($telefone)) {
            return new WP_Error('telefone_invalido', 'Telefone inválido.');
        }

        $provider = get_option('pm_whatsapp_provider', 'dslboot');

        switch ($provider) {

            case 'lumaboot':
                $result = self::send_lumaboot($telefone, $mensagem);
                break;

            case 'api_generica':
                $result = self::send_generic_api($telefone, $mensagem);
                break;

            case 'dslboot':
            default:
                $result = self::send_dslboot($telefone, $mensagem);
                break;
        }

        // Log
        PhotoMusic_Logs::add(
            'whatsapp_envio',
            $extra['id_evento'] ?? null,
            null,
            null,
            'Envio WhatsApp para ' . $telefone
        );

        return $result;
    }

    /* ============================================================
       DSLBOOT
    ============================================================ */
    private static function send_dslboot($telefone, $mensagem) {

        $api_url = get_option('pm_dslboot_url');
        $api_key = get_option('pm_dslboot_key');

        if (!$api_url || !$api_key) {
            return new WP_Error('config_invalida', 'Configuração DSLBoot ausente.');
        }

        $response = wp_remote_post($api_url, [
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json'
            ],
            'body' => json_encode([
                'phone'    => $telefone,
                'message'  => $mensagem
            ])
        ]);

        return self::handle_response($response);
    }

    /* ============================================================
       LUMABOOT
    ============================================================ */
    private static function send_lumaboot($telefone, $mensagem) {

        $api_url = get_option('pm_lumaboot_url');
        $api_key = get_option('pm_lumaboot_key');

        if (!$api_url || !$api_key) {
            return new WP_Error('config_invalida', 'Configuração LumaBoot ausente.');
        }

        $response = wp_remote_post($api_url, [
            'timeout' => 20,
            'headers' => [
                'apikey'       => $api_key,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode([
                'number'   => $telefone,
                'message'  => $mensagem
            ])
        ]);

        return self::handle_response($response);
    }

    /* ============================================================
       API GENÉRICA
    ============================================================ */
    private static function send_generic_api($telefone, $mensagem) {

        $api_url = get_option('pm_generic_api_url');
        $api_key = get_option('pm_generic_api_key');

        if (!$api_url || !$api_key) {
            return new WP_Error('config_invalida', 'Configuração da API genérica ausente.');
        }

        $response = wp_remote_post($api_url, [
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json'
            ],
            'body' => json_encode([
                'to'      => $telefone,
                'message' => $mensagem
            ])
        ]);

        return self::handle_response($response);
    }

    /* ============================================================
       TRATAMENTO DE RESPOSTA
    ============================================================ */
    private static function handle_response($response) {

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code >= 200 && $code < 300) {
            return ['sucesso' => true, 'resposta' => $body];
        }

        return new WP_Error('erro_envio', 'Falha ao enviar mensagem: ' . $body);
    }

    /* ============================================================
       TEMPLATE DE MENSAGEM
    ============================================================ */
    public static function build_message($template, $vars = []) {
        foreach ($vars as $key => $value) {
            $template = str_replace('{' . $key . '}', $value, $template);
        }
        return $template;
    }

    /* ============================================================
       ENVIO DE PDF VIA Z-API
    ============================================================ */
    public static function send_pdf_zapi($telefone, $mensagem, $url_pdf) {

        $telefone = preg_replace('/\D/', '', $telefone);

        if (!filter_var($url_pdf, FILTER_VALIDATE_URL)) {
            return new WP_Error('url_invalida', 'URL do PDF inválida.');
        }

        $instance = get_option('pm_zapi_instance');
        $token    = get_option('pm_zapi_token');

        if (!$instance || !$token) {
            return new WP_Error('config_invalida', 'Configuração Z-API ausente.');
        }

        $endpoint = "https://api.z-api.io/instances/$instance/token/$token/send-document";

        $payload = [
            "phone"    => $telefone,
            "document" => $url_pdf,
            "filename" => basename($url_pdf),
            "caption"  => $mensagem
        ];

        $response = wp_remote_post($endpoint, [
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($payload)
        ]);

        return self::handle_response($response);
    }
}
