<?php
// includes/contratos/class-photomusic-contratos-actions.php

if (!defined('ABSPATH')) exit;

class PhotoMusic_Contratos_Actions {

    /* ============================================================
       REGISTRA TODAS AS AÇÕES admin-post
       ============================================================ */
    public static function init() {

        add_action('admin_post_pm_editar_contrato',      [__CLASS__, 'editar_contrato']);
        add_action('admin_post_pm_enviar_assinatura',    [__CLASS__, 'enviar_para_assinatura']);
        add_action('admin_post_pm_cancelar_contrato',    [__CLASS__, 'cancelar_contrato']);
        add_action('admin_post_pm_assinar_empresa',      [__CLASS__, 'assinar_empresa']);

        // Assinatura pública do contratante
        add_action('admin_post_nopriv_pm_assinar_contratante', [__CLASS__, 'assinar_contratante']);
        add_action('admin_post_pm_assinar_contratante',        [__CLASS__, 'assinar_contratante']);
    }

    /* ============================================================
       EDITAR CONTRATO (ADMIN)
       ============================================================ */
    public static function editar_contrato() {

        if (!check_admin_referer('pm_editar_contrato')) {
            wp_die('Falha na validação de segurança.');
        }

        PhotoMusic_Contratos_Permissoes::validar_editar();

        $id = intval($_POST['contrato_id']);
        $contrato = PhotoMusic_Contratos::get($id);

        if (!$contrato) wp_die('Contrato não encontrado.');

        PhotoMusic_Contratos_Permissoes::validar_status_para_edicao($contrato);

        $dados = [
            'evento_nome'   => sanitize_text_field($_POST['evento_nome']),
            'evento_data'   => sanitize_text_field($_POST['evento_data']),
            'cliente_nome'  => sanitize_text_field($_POST['cliente_nome']),
            'cliente_email' => sanitize_email($_POST['cliente_email']),
            'valor_total'   => floatval($_POST['valor_total']),
        ];

        PhotoMusic_Contratos::atualizar($id, $dados);

        wp_redirect(admin_url('admin.php?page=photomusic_contratos&action=editar&id=' . $id . '&updated=1'));
        exit;
    }

    /* ============================================================
       ENVIAR PARA ASSINATURA INTERNA (ADMIN)
       ============================================================ */
    public static function enviar_para_assinatura() {

        if (!check_admin_referer('pm_enviar_assinatura')) {
            wp_die('Falha na validação de segurança.');
        }

        PhotoMusic_Contratos_Permissoes::validar_enviar();

        $id = intval($_GET['contrato_id']);
        $contrato = PhotoMusic_Contratos::get($id);

        if (!$contrato) wp_die('Contrato não encontrado.');

        PhotoMusic_Contratos_Permissoes::validar_status_para_envio($contrato);

        PhotoMusic_Contratos::set_status($id, 'aguardando_assinatura_admin');

        wp_redirect(admin_url('admin.php?page=photomusic_contratos&action=editar&id=' . $id . '&enviado=1'));
        exit;
    }

    /* ============================================================
       CANCELAR CONTRATO (ADMIN)
       ============================================================ */
    public static function cancelar_contrato() {

        if (!check_admin_referer('pm_cancelar_contrato')) {
            wp_die('Falha na validação de segurança.');
        }

        PhotoMusic_Contratos_Permissoes::validar_cancelar();

        $id = intval($_GET['contrato_id']);
        $contrato = PhotoMusic_Contratos::get($id);

        if (!$contrato) wp_die('Contrato não encontrado.');

        PhotoMusic_Contratos_Permissoes::validar_status_para_cancelar($contrato);

        PhotoMusic_Contratos::set_status($id, 'cancelado');

        wp_redirect(admin_url('admin.php?page=photomusic_contratos&cancelado=1'));
        exit;
    }

    /* ============================================================
       ASSINAR COMO EMPRESA (ADMIN)
       ============================================================ */
    public static function assinar_empresa() {

        if (!check_admin_referer('pm_assinar_empresa')) {
            wp_die('Falha na validação de segurança.');
        }

        if (!PhotoMusic_Contratos_Permissoes::pode_assinar()) {
            wp_die('Você não tem permissão para assinar contratos como empresa.');
        }

        $id = intval($_GET['contrato_id']);
        $contrato = PhotoMusic_Contratos::get($id);

        if (!$contrato) wp_die('Contrato não encontrado.');

        PhotoMusic_Contratos::registrar_assinatura_admin(
            $id,
            wp_get_current_user()->display_name,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        );

        wp_redirect(admin_url('admin.php?page=photomusic_contratos&assinado_empresa=1'));
        exit;
    }

    /* ============================================================
       ASSINATURA DO CONTRATANTE (PÚBLICA)
       ============================================================ */
    public static function assinar_contratante() {

        if (!check_admin_referer('pm_assinar_contratante')) {
            wp_die('Falha na validação de segurança.');
        }

        $id = intval($_POST['contrato_id']);
        $contrato = PhotoMusic_Contratos::get($id);

        if (!$contrato) wp_die('Contrato não encontrado.');

        if ($contrato->status_contrato !== 'aguardando_assinatura_contratante') {
            wp_die('Este contrato não está disponível para assinatura.');
        }

        $nome = sanitize_text_field($_POST['nome']);

        PhotoMusic_Contratos::registrar_assinatura_contratante(
            $id,
            $nome,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        );

        wp_redirect(add_query_arg('assinado', '1', wp_get_referer()));
        exit;
    }
}
