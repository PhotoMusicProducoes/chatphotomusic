<?php
// includes/core/class-photomusic-installer.php

if (!defined('ABSPATH')) exit;

class PhotoMusic_Installer {

    /**
     * Executado na ativação do plugin
     */
    public static function activate() {
        self::create_tables();
        self::create_roles_and_caps();
    }

    /**
     * Criação de todas as tabelas do sistema
     */
    private static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        // Nomes das tabelas
        $tbl_eventos             = $wpdb->prefix . 'pm_eventos';
        $tbl_termos              = $wpdb->prefix . 'pm_termos_versoes';
        $tbl_convites            = $wpdb->prefix . 'pm_convites';
        $tbl_aceites             = $wpdb->prefix . 'pm_aceites';
        $tbl_logs                = $wpdb->prefix . 'pm_logs_sistema';
        $tbl_senhas              = $wpdb->prefix . 'pm_eventos_senhas';
        $tbl_acessos             = $wpdb->prefix . 'pm_acessos_galeria';
        $tbl_aceite_contratante  = $wpdb->prefix . 'pm_aceite_contratante';
        $tbl_event_services      = $wpdb->prefix . 'pm_event_services';
        $tbl_aceites_evento      = $wpdb->prefix . 'pm_aceites_evento';
        $tbl_acessos_evento      = $wpdb->prefix . 'pm_acessos_evento';
        $tbl_compartilhamentos   = $wpdb->prefix . 'pm_compartilhamentos';
        $tbl_devices             = $wpdb->prefix . 'pm_devices';
        $tbl_whatsapp_logs       = $wpdb->prefix . 'pm_evento_whatsapp_logs';

        // Módulo 5
        $tbl_event_items         = $wpdb->prefix . 'pm_event_items';
        $tbl_event_history       = $wpdb->prefix . 'pm_event_history';
        $tbl_event_messages      = $wpdb->prefix . 'pm_event_messages';
        $tbl_contratantes        = $wpdb->prefix . 'pm_contratantes';
        $tbl_contratos           = $wpdb->prefix . 'pm_contratos';

        // Módulo Serviços
        $tbl_servicos            = $wpdb->prefix . 'pm_servicos';
        $tbl_servicos_subtipos   = $wpdb->prefix . 'pm_servicos_subtipos';
        $tbl_servicos_pacotes    = $wpdb->prefix . 'pm_servicos_pacotes';
        $tbl_servicos_regras     = $wpdb->prefix . 'pm_servicos_regras';
        $tbl_eventos_servicos    = $wpdb->prefix . 'pm_eventos_servicos';

        // Módulo Ideias e Projetos
        $tbl_ideias_futuras      = $wpdb->prefix . 'pm_ideias_futuras';
        $tbl_projetos            = $wpdb->prefix . 'pm_projetos';

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        /* ============================================================
           TABELA: EVENTOS
        ============================================================ */
        $sql_eventos = "CREATE TABLE $tbl_eventos (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            tipo_evento ENUM('PF','PJ') NOT NULL,

            nome_contratante VARCHAR(255) NULL,
            cpf VARCHAR(20) NULL,

            razao_social VARCHAR(255) NULL,
            cnpj VARCHAR(20) NULL,
            responsavel VARCHAR(255) NULL,

            motivo_evento VARCHAR(255) NOT NULL,

            data_evento DATE NULL,
            status_evento ENUM('ativo','desativado') NOT NULL DEFAULT 'ativo',

            codigo_interno VARCHAR(100) NULL,
            criado_por BIGINT UNSIGNED NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,

            INDEX idx_tipo (tipo_evento),
            INDEX idx_status (status_evento)
        ) $charset;";

        /* ============================================================
           TABELA: SERVIÇOS DO EVENTO
        ============================================================ */
        $sql_event_services = "CREATE TABLE $tbl_event_services (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_evento BIGINT UNSIGNED NOT NULL,

            nome_servico VARCHAR(255) NOT NULL,
            slug_servico VARCHAR(255) NOT NULL,
            tipo ENUM('foto','video','360','gif','outro') NOT NULL DEFAULT 'foto',
            status_servico ENUM('ativo','desativado') NOT NULL DEFAULT 'ativo',

            link_convidado VARCHAR(500) NOT NULL,
            link_contratante VARCHAR(500) NOT NULL,

            regras_acesso LONGTEXT NOT NULL,

            pasta_protegida VARCHAR(500) NOT NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento),
            INDEX idx_slug (slug_servico)
        ) $charset;";

        /* ============================================================
           TABELA: ACESSOS À GALERIA (CONVIDADOS)
        ============================================================ */
        $sql_acessos = "CREATE TABLE $tbl_acessos (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_evento INT UNSIGNED NOT NULL,
            id_servico BIGINT UNSIGNED NOT NULL,

            telefone VARCHAR(30) NOT NULL,
            token_acesso VARCHAR(64) NOT NULL UNIQUE,
            device_hash VARCHAR(255) NOT NULL,

            acessos_hoje INT UNSIGNED NOT NULL DEFAULT 0,
            acessos_total INT UNSIGNED NOT NULL DEFAULT 0,

            ultimo_acesso DATE NULL,
            expira_em DATETIME NULL,

            ip VARCHAR(45) NULL,
            navegador VARCHAR(255) NULL,
            dispositivo VARCHAR(255) NULL,
            user_agent TEXT NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_evento_telefone (id_evento, telefone),
            INDEX idx_servico (id_servico)
        ) $charset;";

        /* ============================================================
           TABELA: ACEITE DO CONTRATANTE
        ============================================================ */
        $sql_aceite_contratante = "CREATE TABLE $tbl_aceite_contratante (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_evento INT UNSIGNED NOT NULL,
            tipo_evento ENUM('PF','PJ') NOT NULL,

            nome_contratante VARCHAR(255) NOT NULL,
            email_contratante VARCHAR(255) NULL,

            ip VARCHAR(45) NOT NULL,
            navegador VARCHAR(255) NULL,
            dispositivo VARCHAR(255) NULL,
            user_agent TEXT NULL,

            device_hash VARCHAR(255) NOT NULL DEFAULT '',
            total_acessos INT UNSIGNED NOT NULL DEFAULT 1,
            ultimo_acesso DATETIME NULL,

            aceite_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            versao_termo VARCHAR(20) NOT NULL DEFAULT '1.0',

            INDEX idx_evento (id_evento),
            INDEX idx_tipo_evento (tipo_evento),
            INDEX idx_device (id_evento, device_hash)
        ) $charset;";
        /* ============================================================
           TABELA: TERMOS DE USO
        ============================================================ */
        $sql_termos = "CREATE TABLE $tbl_termos (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            versao VARCHAR(20) NOT NULL,
            idioma CHAR(2) NOT NULL,
            titulo VARCHAR(255) NOT NULL,
            conteudo LONGTEXT NOT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) $charset;";

        /* ============================================================
           TABELA: CONVITES
        ============================================================ */
        $sql_convites = "CREATE TABLE $tbl_convites (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_evento INT UNSIGNED NOT NULL,

            token_convite VARCHAR(64) NOT NULL UNIQUE,
            telefone VARCHAR(30) NULL,
            email VARCHAR(255) NULL,
            nome_convidado VARCHAR(255) NULL,

            canal_origem VARCHAR(50) NOT NULL,
            idioma_preferido CHAR(2) NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            expirado_em DATETIME NULL,

            INDEX idx_evento (id_evento)
        ) $charset;";

        /* ============================================================
        TABELA: SENHAS POR DIA
        ============================================================ */
        $sql_senhas = "CREATE TABLE $tbl_senhas (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_evento INT UNSIGNED NOT NULL,
            data_evento DATE NOT NULL,
            senha_hash VARCHAR(255) NOT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_evento (id_evento, data_evento)
        ) $charset;";


        /* ============================================================
        MÓDULO 5 — ITENS DE SERVIÇO DO EVENTO
        ============================================================ */
        $sql_event_items = "CREATE TABLE $tbl_event_items (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_service BIGINT UNSIGNED NOT NULL,

            item VARCHAR(255) NOT NULL,
            quantidade INT UNSIGNED NOT NULL DEFAULT 1,
            valor DECIMAL(10,2) NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_service (id_service)
        ) $charset;";


        /* ============================================================
        MÓDULO 5 — HISTÓRICO DO EVENTO
        ============================================================ */
        $sql_event_history = "CREATE TABLE $tbl_event_history (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_evento BIGINT UNSIGNED NOT NULL,

            acao VARCHAR(255) NOT NULL,
            detalhes TEXT NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento)
        ) $charset;";


        /* ============================================================
        MÓDULO 5 — MENSAGENS DO EVENTO (WHATSAPP)
        ============================================================ */
        $sql_event_messages = "CREATE TABLE $tbl_event_messages (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_evento BIGINT UNSIGNED NOT NULL,

            chat_id VARCHAR(50) NOT NULL,
            direction ENUM('sent','received') NOT NULL,
            tipo VARCHAR(50) NOT NULL,
            mensagem TEXT NULL,

            enviado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento),
            INDEX idx_chat (chat_id)
        ) $charset;";


        /* ============================================================
        TABELA: CONTRATANTES (PF e PJ)
        ============================================================ */
        $sql_contratantes = "CREATE TABLE $tbl_contratantes (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            tipo VARCHAR(2) NOT NULL DEFAULT 'PF',

            telefone VARCHAR(30) NULL,
            email VARCHAR(255) NULL,
            instagram VARCHAR(255) NULL,
            facebook VARCHAR(255) NULL,

            logradouro VARCHAR(255) NULL,
            numero VARCHAR(20) NULL,
            complemento VARCHAR(255) NULL,
            bairro VARCHAR(255) NULL,
            cidade VARCHAR(255) NULL,
            estado VARCHAR(10) NULL,
            cep VARCHAR(20) NULL,

            nome VARCHAR(255) NULL,
            cpf VARCHAR(20) NULL,
            rg VARCHAR(30) NULL,
            rg_orgao VARCHAR(50) NULL,
            data_nascimento DATE NULL,
            parentesco VARCHAR(255) NULL,

            nome_fantasia VARCHAR(255) NULL,
            razao_social VARCHAR(255) NULL,
            cnpj VARCHAR(30) NULL,

            representante_nome VARCHAR(255) NULL,
            representante_cpf VARCHAR(20) NULL,
            representante_rg VARCHAR(30) NULL,
            representante_rg_orgao VARCHAR(50) NULL,
            representante_data_nascimento DATE NULL,
            representante_celular VARCHAR(30) NULL,

            token_acesso VARCHAR(64) NULL UNIQUE,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_tipo (tipo),
            INDEX idx_telefone (telefone),
            INDEX idx_email (email),
            INDEX idx_cnpj (cnpj),
            INDEX idx_cpf (cpf)
            INDEX idx_token_acesso (token_acesso)
        ) $charset;";


        /* ============================================================
        TABELA: CONTRATOS DO EVENTO
        ============================================================ */
        $sql_contratos = "CREATE TABLE $tbl_contratos (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_evento BIGINT UNSIGNED NOT NULL,
            id_contratante BIGINT UNSIGNED NULL,

            token VARCHAR(64) NOT NULL UNIQUE,

            tipo_contrato ENUM('completo','simplificado') NOT NULL DEFAULT 'completo',

            status_contrato ENUM(
                'rascunho',
                'aguardando_assinatura_admin',
                'aguardando_assinatura_contratante',
                'assinado',
                'assinado_admin',
                'assinado_contratante',
                'dispensado',
                'cancelado'
            ) NOT NULL DEFAULT 'rascunho',

            tipo_assinatura ENUM(
                'digital_sistema',
                'manual_papel',
                'govbr',
                'nao_assinado'
            ) NOT NULL DEFAULT 'nao_assinado',

            conteudo LONGTEXT NULL,
            pdf_final VARCHAR(500) NULL,

            assinatura_contratante_nome VARCHAR(255) NULL,
            assinatura_contratante_data DATETIME NULL,
            assinatura_contratante_ip VARCHAR(50) NULL,
            assinatura_contratante_useragent TEXT NULL,
            assinatura_contratante_hash VARCHAR(255) NULL,

            assinatura_admin_nome VARCHAR(255) NULL,
            assinatura_admin_data DATETIME NULL,
            assinatura_admin_ip VARCHAR(50) NULL,
            assinatura_admin_useragent TEXT NULL,
            assinatura_admin_hash VARCHAR(255) NULL,

            hash_contrato VARCHAR(255) NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento),
            INDEX idx_contratante (id_contratante)
        ) $charset;";

        /* ============================================================
        MÓDULO SERVIÇOS — SUBTIPOS
        ============================================================ */
        $sql_servicos_subtipos = "CREATE TABLE $tbl_servicos_subtipos (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_servico BIGINT UNSIGNED NOT NULL,
            nome VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL,

            ativo TINYINT(1) NOT NULL DEFAULT 1,
            ordem INT UNSIGNED NOT NULL DEFAULT 0,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_servico (id_servico),
            INDEX idx_slug (slug)
        ) $charset;";


        /* ============================================================
        MÓDULO SERVIÇOS — PACOTES
        ============================================================ */
        $sql_servicos_pacotes = "CREATE TABLE $tbl_servicos_pacotes (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_servico BIGINT UNSIGNED NOT NULL,
            id_subtipo BIGINT UNSIGNED NULL,

            titulo VARCHAR(255) NOT NULL,
            descricao TEXT NULL,

            horas_min INT UNSIGNED NULL,
            horas_max INT UNSIGNED NULL,

            fotos_min INT UNSIGNED NULL,
            fotos_max INT UNSIGNED NULL,

            valor_base DECIMAL(10,2) NOT NULL DEFAULT 0,
            valor_hora_extra DECIMAL(10,2) NULL,

            ativo TINYINT(1) NOT NULL DEFAULT 1,
            ordem INT UNSIGNED NOT NULL DEFAULT 0,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_servico (id_servico),
            INDEX idx_subtipo (id_subtipo)
        ) $charset;";


        /* ============================================================
        MÓDULO SERVIÇOS — REGRAS POR CELEBRAÇÃO
        ============================================================ */
        $sql_servicos_regras = "CREATE TABLE $tbl_servicos_regras (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_servico BIGINT UNSIGNED NOT NULL,
            celebracao VARCHAR(100) NOT NULL,

            horas_min INT UNSIGNED NULL,
            horas_max INT UNSIGNED NULL,

            fotos_min INT UNSIGNED NULL,
            fotos_max INT UNSIGNED NULL,

            valor_min DECIMAL(10,2) NULL,
            valor_max DECIMAL(10,2) NULL,

            ativo TINYINT(1) NOT NULL DEFAULT 1,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_servico (id_servico),
            INDEX idx_celebracao (celebracao)
        ) $charset;";


        /* ============================================================
        MÓDULO SERVIÇOS — SERVIÇOS CONTRATADOS POR EVENTO
        ============================================================ */
        $sql_eventos_servicos = "CREATE TABLE $tbl_eventos_servicos (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_evento BIGINT UNSIGNED NOT NULL,
            id_servico BIGINT UNSIGNED NOT NULL,
            id_subtipo BIGINT UNSIGNED NULL,
            id_pacote BIGINT UNSIGNED NULL,

            horas_contratadas INT UNSIGNED NULL,
            fotos_contratadas INT UNSIGNED NULL,

            valor_base DECIMAL(10,2) NOT NULL DEFAULT 0,
            valor_adicional DECIMAL(10,2) NULL,
            valor_final DECIMAL(10,2) NOT NULL DEFAULT 0,

            observacoes TEXT NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento),
            INDEX idx_servico (id_servico),
            INDEX idx_pacote (id_pacote)
        ) $charset;";


        /* ============================================================
        TABELA: ACEITES DO CONVIDADO (NOVO FLUXO)
        ============================================================ */
        $sql_aceites_evento = "CREATE TABLE $tbl_aceites_evento (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_evento BIGINT UNSIGNED NOT NULL,
            id_servico BIGINT UNSIGNED NULL,
            id_convite BIGINT UNSIGNED NULL,

            nome VARCHAR(255) NULL,
            telefone VARCHAR(30) NULL,
            email VARCHAR(255) NULL,

            ip VARCHAR(45) NULL,
            navegador VARCHAR(150) NULL,
            dispositivo VARCHAR(100) NULL,
            user_agent TEXT NULL,

            aceite_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento),
            INDEX idx_servico (id_servico),
            INDEX idx_telefone (telefone)
        ) $charset;";


        /* ============================================================
        TABELA: ACESSOS DO CONVIDADO (NOVO FLUXO)
        ============================================================ */
        $sql_acessos_evento = "CREATE TABLE $tbl_acessos_evento (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_evento BIGINT UNSIGNED NOT NULL,
            id_servico BIGINT UNSIGNED NOT NULL,

            token VARCHAR(64) NOT NULL UNIQUE,
            telefone VARCHAR(30) NULL,
            email VARCHAR(255) NULL,

            acessos INT UNSIGNED NOT NULL DEFAULT 0,
            ultimo_acesso DATETIME NULL,

            ip VARCHAR(45) NULL,
            dispositivo VARCHAR(255) NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento),
            INDEX idx_servico (id_servico)
        ) $charset;";


        /* ============================================================
        TABELA: COMPARTILHAMENTO DE LINKS
        ============================================================ */
        $sql_compartilhamentos = "CREATE TABLE $tbl_compartilhamentos (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_evento BIGINT UNSIGNED NOT NULL,
            id_servico BIGINT UNSIGNED NOT NULL,

            token VARCHAR(64) NOT NULL UNIQUE,
            compartilhado_por VARCHAR(255) NULL,
            enviado_para VARCHAR(255) NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento),
            INDEX idx_servico (id_servico)
        ) $charset;";


        /* ============================================================
        TABELA: DISPOSITIVOS
        ============================================================ */
        $sql_devices = "CREATE TABLE $tbl_devices (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            device_hash VARCHAR(255) NOT NULL UNIQUE,
            user_agent TEXT NULL,
            navegador VARCHAR(255) NULL,
            dispositivo VARCHAR(255) NULL,
            ip VARCHAR(45) NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) $charset;";


        /* ============================================================
        TABELA: LOGS DO WHATSAPP
        ============================================================ */
        $sql_whatsapp_logs = "CREATE TABLE $tbl_whatsapp_logs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_evento BIGINT UNSIGNED NOT NULL,
            chat_id VARCHAR(50) NOT NULL,
            direction ENUM('sent','received') NOT NULL,
            mensagem TEXT NULL,

            enviado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento),
            INDEX idx_chat (chat_id)
        ) $charset;";   

        /* ============================================================
        TABELA: ACEITES DE CONVIDADOS
        ============================================================ */
        $sql_aceites = "CREATE TABLE $tbl_aceites (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_convite BIGINT UNSIGNED NULL,
            id_evento INT UNSIGNED NOT NULL,
            id_servico BIGINT UNSIGNED NULL,
            id_termos_versao INT UNSIGNED NULL,

            nome VARCHAR(255) NULL,
            telefone VARCHAR(30) NULL,
            email VARCHAR(255) NULL,

            ip VARCHAR(45) NULL,
            pais VARCHAR(100) NULL,
            estado VARCHAR(100) NULL,
            cidade VARCHAR(100) NULL,
            navegador VARCHAR(255) NULL,
            sistema_operacional VARCHAR(100) NULL,
            dispositivo VARCHAR(100) NULL,
            user_agent TEXT NULL,
            idioma_navegador VARCHAR(10) NULL,
            canal_origem VARCHAR(50) NULL,

            aceite_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status_envio VARCHAR(50) NULL DEFAULT 'pendente',

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento),
            INDEX idx_telefone (telefone),
            INDEX idx_email (email)
        ) $charset;";


        /* ============================================================
        TABELA: LOGS DO SISTEMA
        ============================================================ */
        $sql_logs = "CREATE TABLE $tbl_logs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            tipo VARCHAR(100) NOT NULL,

            id_evento INT UNSIGNED NULL,
            id_servico BIGINT UNSIGNED NULL,
            id_convite BIGINT UNSIGNED NULL,
            id_aceite BIGINT UNSIGNED NULL,

            mensagem TEXT NULL,

            ip VARCHAR(45) NULL,
            navegador VARCHAR(255) NULL,
            dispositivo VARCHAR(100) NULL,
            user_agent TEXT NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_tipo (tipo),
            INDEX idx_evento (id_evento)
        ) $charset;";


        /* ============================================================
        MÓDULO SERVIÇOS — CATÁLOGO BASE
        ============================================================ */
        $sql_servicos = "CREATE TABLE $tbl_servicos (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            nome VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL UNIQUE,
            descricao TEXT NULL,

            ativo TINYINT(1) NOT NULL DEFAULT 1,
            ordem INT UNSIGNED NOT NULL DEFAULT 0,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

            INDEX idx_slug (slug),
            INDEX idx_ativo (ativo)
        ) $charset;";


        /* ============================================================
        MÓDULO IDEIAS FUTURAS
        ============================================================ */
        $sql_ideias_futuras = "CREATE TABLE $tbl_ideias_futuras (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            titulo VARCHAR(255) NOT NULL,
            descricao LONGTEXT NULL,
            status ENUM('nova','aprovada','em_andamento','concluida','descartada')
                NOT NULL DEFAULT 'nova',
            prioridade ENUM('baixa','media','alta','critica') NOT NULL DEFAULT 'media',

            criado_por BIGINT UNSIGNED NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,

            INDEX idx_status (status),
            INDEX idx_prioridade (prioridade)
        ) $charset;";


        /* ============================================================
        MÓDULO PROJETOS
        ============================================================ */
        $sql_projetos = "CREATE TABLE $tbl_projetos (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_ideia BIGINT UNSIGNED NULL,
            titulo VARCHAR(255) NOT NULL,
            descricao LONGTEXT NULL,
            status ENUM('planejado','em_andamento','pausado','concluido','cancelado')
                NOT NULL DEFAULT 'planejado',

            responsavel BIGINT UNSIGNED NULL,
            previsao_conclusao DATE NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,

            INDEX idx_status (status),
            INDEX idx_ideia (id_ideia)
        ) $charset;";


        /* ============================================================
        TABELA FINANCEIRO — MOVIMENTOS
        ============================================================ */
        self::create_table_financeiro();


        /* ============================================================
        EXECUTAR TODAS AS TABELAS
        ============================================================ */
        dbDelta($sql_eventos);
        dbDelta($sql_event_services);
        dbDelta($sql_convites);
        dbDelta($sql_aceites);
        dbDelta($sql_acessos);
        dbDelta($sql_senhas);
        dbDelta($sql_logs);
        dbDelta($sql_termos);
        dbDelta($sql_aceite_contratante);

        // Módulo 5
        dbDelta($sql_event_items);
        dbDelta($sql_event_history);
        dbDelta($sql_event_messages);
        dbDelta($sql_contratantes);
        dbDelta($sql_contratos);

        dbDelta($sql_aceites_evento);
        dbDelta($sql_acessos_evento);
        dbDelta($sql_compartilhamentos);
        dbDelta($sql_devices);
        dbDelta($sql_whatsapp_logs);

        dbDelta($sql_servicos);
        dbDelta($sql_servicos_subtipos);
        dbDelta($sql_servicos_pacotes);
        dbDelta($sql_servicos_regras);
        dbDelta($sql_eventos_servicos);

        dbDelta($sql_ideias_futuras);
        dbDelta($sql_projetos);

    } // fim create_tables()

    private static function create_roles_and_caps() {

        /* ============================================================
        ROLES — PAPÉIS DO SISTEMA
        ============================================================ */

        add_role('photomusic_admin', 'PhotoMusic Admin', []);
        add_role('photomusic_user', 'PhotoMusic User', []);


        /* ============================================================
        CAPABILITIES — PADRÃO DO SISTEMA
        ============================================================ */

        $caps = [
            'pm_gerenciar_usuarios',
            'pm_ver_eventos',
            'pm_criar_eventos',
            'pm_editar_eventos',
            'pm_desativar_eventos',
            'pm_ver_dados_evento',
            'pm_gerar_pdf',
            'pm_gerar_excel',
            'pm_ver_logs',
            'pm_ver_contratos',
            'pm_criar_contratos',
            'pm_assinar_contratos',
            'pm_subir_contrato_assinado',
            'pm_cancelar_contratos',
            'photomusic_view_roadmap',
        ];


        /* ============================================================
        CAPABILITIES — IDEIAS FUTURAS E PROJETOS
        ============================================================ */

        $caps_ideias_projetos = [
            'pm_ideias_view',
            'pm_ideias_edit',
            'pm_ideias_priorizar',
            'pm_ideias_aprovar',
            'pm_projetos_criar',
            'pm_projetos_editar',
            'pm_projetos_concluir',
        ];


        /* ============================================================
        ATRIBUI CAPABILITIES AO PAPEL photomusic_admin
        ============================================================ */

        $role_admin = get_role('photomusic_admin');
        if ($role_admin) {

            // caps padrão
            foreach ($caps as $cap) {
                $role_admin->add_cap($cap);
            }

            // caps novas
            foreach ($caps_ideias_projetos as $cap) {
                $role_admin->add_cap($cap);
            }
        }


        /* ============================================================
        ATRIBUI CAPABILITIES AO PAPEL photomusic_user
        ============================================================ */

        $role_user = get_role('photomusic_user');
        if ($role_user) {

            // caps básicas
            $role_user->add_cap('pm_ver_eventos');
            $role_user->add_cap('pm_ideias_view');
            $role_user->add_cap('pm_ideias_edit'); // pode sugerir ideias
        }


        /* ============================================================
        ATRIBUI CAPABILITIES AO ADMINISTRADOR NATIVO DO WORDPRESS
        ============================================================ */

        $role_wp_admin = get_role('administrator');
        if ($role_wp_admin) {

            // caps padrão
            foreach ($caps as $cap) {
                $role_wp_admin->add_cap($cap);
            }

            // caps novas
            foreach ($caps_ideias_projetos as $cap) {
                $role_wp_admin->add_cap($cap);
            }
        }
    }//Fim create_roles_and_caps()

    /* ============================================================
    CRIA TABELA DE MOVIMENTOS FINANCEIROS
    ============================================================ */
    private static function create_table_financeiro() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $tbl = $wpdb->prefix . 'pm_financeiro_movimentos';

        $sql = "CREATE TABLE $tbl (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

            id_evento BIGINT UNSIGNED NOT NULL,

            tipo ENUM('entrada','saida') NOT NULL DEFAULT 'entrada',
            categoria VARCHAR(100) NULL,
            descricao TEXT NULL,

            valor DECIMAL(10,2) NOT NULL DEFAULT 0,
            data_movimento DATE NULL,

            forma_pagamento VARCHAR(100) NULL,
            status_pagamento ENUM('pendente','pago','cancelado')
                NOT NULL DEFAULT 'pendente',

            observacoes TEXT NULL,
            registrado_por BIGINT UNSIGNED NULL,

            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,

            INDEX idx_evento (id_evento),
            INDEX idx_tipo (tipo),
            INDEX idx_status (status_pagamento)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

}