<?php
// includes/core/class-photomusic-admin-menu.php

if (!defined('ABSPATH')) exit;

class PhotoMusic_Admin_Menu {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'register_submenus']);
    }

    public static function register_submenus() {

        if (PhotoMusic_Users::current_user_can('pm_ver_eventos')) {
            // DEPOIS:
            add_submenu_page(
                'photomusic-eventos',
                'Configurações',
                'Configurações',
                'pm_gerenciar_usuarios',
                'photomusic-config',
                ['PhotoMusic_Config', 'render_page']  // ← CORRETO
            );
        }

        add_submenu_page(
            null,
            'Detalhes do Contrato',
            'Detalhes do Contrato',
            'pm_ver_eventos',
            'photomusic-contrato-detalhes',
            [__CLASS__, 'render_contrato_detalhes_page']
        );

        add_submenu_page(
            null,
            'Detalhes do Evento',
            'Detalhes do Evento',
            'pm_ver_eventos',
            'photomusic-evento-detalhes',
            [__CLASS__, 'render_evento_detalhes_page']
        );

        add_submenu_page(
            null,
            'Operador do Evento',
            'Operador do Evento',
            'pm_ver_eventos',
            'photomusic-evento-operador',
            [__CLASS__, 'render_evento_operador_page']
        );


        if (PhotoMusic_Users::can_create_event()) {
            add_submenu_page(
                'photomusic-eventos',
                'Convites',
                'Convites',
                'pm_criar_eventos',
                'photomusic-convites',
                [__CLASS__, 'render_convites_page']
            );
        }

        if (PhotoMusic_Users::is_user()) {
            add_submenu_page(
                'photomusic-eventos',
                'Aceites',
                'Aceites',
                'pm_ver_eventos',
                'photomusic-aceites',
                [__CLASS__, 'render_aceites_page']
            );
        }

        if (PhotoMusic_Users::can_view_logs()) {
            add_submenu_page(
                'photomusic-eventos',
                'Relatório de Aceites',
                'Relatório de Aceites',
                'pm_ver_logs',
                'photomusic-relatorio-aceites',
                ['PhotoMusic_Aceites', 'render_relatorio']
            );
        }

        if (PhotoMusic_Users::can_view_logs()) {
            add_submenu_page(
                'photomusic-eventos',
                'Logs do Sistema',
                'Logs',
                'pm_ver_logs',
                'photomusic-logs',
                [__CLASS__, 'render_logs_page']
            );
        }

        if (PhotoMusic_Users::is_admin()) {
            add_submenu_page(
                'photomusic-eventos',
                'Configurações',
                'Configurações',
                'pm_gerenciar_usuarios',
                'photomusic-config',
                ['PhotoMusic_Config', 'render_page']
            );
        }
    }

    /* ============================================================
       LISTAGEM DE CONTRATOS
    ============================================================ */
    public static function render_contratos_page() {

        if (!PhotoMusic_Users::current_user_can('pm_ver_eventos')) {
            wp_die('Você não tem permissão para acessar esta página.');
        }

        echo '<div class="wrap"><h1>Contratos dos Eventos</h1>';

        global $wpdb;

        $contratos = $wpdb->get_results("
            SELECT c.*, e.motivo_evento, e.data_evento
            FROM {$wpdb->prefix}pm_contratos c
            LEFT JOIN {$wpdb->prefix}pm_eventos e ON e.id = c.id_evento
            ORDER BY c.id DESC
        ");

        if (!$contratos) {
            echo '<p>Nenhum contrato encontrado.</p></div>';
            return;
        }

        echo '<table class="widefat striped" style="margin-top:20px;">';
        echo '<thead><tr>
                <th>ID</th>
                <th>Evento</th>
                <th>Data</th>
                <th>Status</th>
                <th>Assinaturas</th>
                <th>PDF</th>
                <th>Ações</th>
              </tr></thead><tbody>';

        foreach ($contratos as $c) {

            $assinaturas =
                ($c->assinatura_admin_data ? 'Admin ✔' : 'Admin ✖') . '<br>' .
                ($c->assinatura_contratante_data ? 'Contratante ✔' : 'Contratante ✖');

            $pdf_btn = $c->pdf_final
                ? '<a class="button" target="_blank" href="' . esc_url($c->pdf_final) . '">Baixar PDF</a>'
                : '<em>Não gerado</em>';

            $link_publico = home_url('/contrato/' . $c->token);

            echo '<tr>';
            echo '<td>' . intval($c->id) . '</td>';
            echo '<td>' . esc_html($c->motivo_evento) . '</td>';
            echo '<td>' . esc_html($c->data_evento) . '</td>';
            echo '<td>' . esc_html($c->status_contrato) . '</td>';
            echo '<td>' . $assinaturas . '</td>';
            echo '<td>' . $pdf_btn . '</td>';
            echo '<td>
                    <a class="button" target="_blank" href="' . esc_url($link_publico) . '">Ver Contrato</a>
                    <a class="button button-secondary" href="' . admin_url('admin.php?page=photomusic-contrato-detalhes&id=' . $c->id) . '">Detalhes</a>
                    <a class="button button-secondary" href="' . admin_url('admin.php?page=photomusic-evento-detalhes&id=' . $c->id_evento) . '">Ver Evento</a>
                  </td>';
            echo '</tr>';
        }

        echo '</tbody></table></div>';
    }

    /* ============================================================
       DETALHES DO CONTRATO
    ============================================================ */
    public static function render_contrato_detalhes_page() {

        /* -------------------------
           ENVIAR PDF POR WHATSAPP
        -------------------------- */
        $enviar_whatsapp = isset($_GET['enviar_whatsapp']) ? intval($_GET['enviar_whatsapp']) : 0;

        if ($enviar_whatsapp > 0) {
            $id_contrato = $enviar_whatsapp;

            $contrato = PhotoMusic_Contratos::get($id_contrato);

            if ($contrato && $contrato->pdf_final) {

                $contratante_obj = PhotoMusic_Contratantes::get_by_event($contrato->id_evento);
                $telefone = $contratante_obj
                    ? preg_replace('/\D/', '', $contratante_obj->telefone ?? '')
                    : '';

                PhotoMusic_WhatsApp::send_pdf(
                    $telefone,
                    "Olá! Segue o contrato do seu evento.",
                    $contrato->pdf_final,
                    ['id_evento' => $contrato->id_evento]
                );

                wp_redirect(admin_url('admin.php?page=photomusic-contrato-detalhes&id=' . $id_contrato . '&whatsapp_ok=1'));
                exit;
            }
        }

        if (!empty($_GET['whatsapp_ok'])) {
            echo '<div class="updated"><p>PDF enviado por WhatsApp com sucesso!</p></div>';
        }

        /* -------------------------
           REGERAR PDF
        -------------------------- */
        $regerar_pdf = isset($_GET['regerar_pdf']) ? intval($_GET['regerar_pdf']) : 0;

        if ($regerar_pdf > 0) {
            $id_contrato = $regerar_pdf;

            $contrato = PhotoMusic_Contratos::get($id_contrato);

            if ($contrato) {

                PhotoMusic_Contratos_PDF::gerar_pdf($contrato);

                PhotoMusic_Contratos::registrar_log(
                    $contrato->id,
                    'pdf_regenerado',
                    'PDF regenerado manualmente.'
                );

                wp_redirect(admin_url('admin.php?page=photomusic-contrato-detalhes&id=' . $id_contrato . '&pdf_ok=1'));
                exit;
            }
        }

        if (!empty($_GET['pdf_ok'])) {
            echo '<div class="updated"><p>PDF regenerado com sucesso!</p></div>';
        }

        /* -------------------------
           CARREGAR CONTRATO
        -------------------------- */
        $id_contrato = isset($_GET['id']) ? intval($_GET['id']) : 0;

        if ($id_contrato <= 0) {
            echo '<div class="wrap"><h1>Contrato não encontrado</h1></div>';
            return;
        }

        $contrato = PhotoMusic_Contratos::get($id_contrato);

        if (!$contrato) {
            echo '<div class="wrap"><h1>Contrato não encontrado</h1></div>';
            return;
        }

        $id_evento = $contrato->id_evento;
        $core = new PhotoMusic_Events_Core();
        $evento = $core->get_evento_completo($id_evento);

        echo '<div class="wrap">';
        echo '<h1>Contrato #' . $contrato->id . '</h1>';
        echo '<a class="button" href="' . admin_url('admin.php?page=photomusic-contratos') . '">← Voltar</a>';
        echo '<hr>';

        echo '<h2>Contrato</h2>';
        echo '<table class="widefat striped">';
        echo '<tr><th>Status</th><td>' . esc_html($contrato->status_contrato) . '</td></tr>';
        echo '<tr><th>Token</th><td>' . esc_html($contrato->token) . '</td></tr>';
        echo '<tr><th>PDF</th><td>';

        if ($contrato->pdf_final) {
            echo '<a class="button button-primary" target="_blank" href="' . esc_url($contrato->pdf_final) . '">Baixar PDF</a> ';
            echo '<a class="button button-secondary" href="' . esc_url(admin_url('admin.php?page=photomusic-contrato-detalhes&id=' . intval($contrato->id))) . '">Regerar PDF</a> ';
            echo '<a class="button" href="' . admin_url('admin.php?page=photomusic-contrato-detalhes&enviar_whatsapp=' . $contrato->id) . '">Enviar por WhatsApp</a>';
        } else {
            echo '<em>PDF não gerado</em>';
        }

        echo '</td></tr></table>';

        echo '<hr>';

        echo '<h2>Conteúdo do Contrato</h2>';
        echo '<div style="background:#fff; padding:20px; border:1px solid #ccc;">';
        echo wp_kses_post($contrato->conteudo);
        echo '</div>';

        echo '<hr>';

        if ($contrato->pdf_final) {
            echo '<h2>Visualização do PDF</h2>';
            echo '<iframe src="' . esc_url($contrato->pdf_final) . '" style="width:100%; height:600px;"></iframe>';
        }

        echo '</div>';
    }

    /* ============================================================
       DETALHES DO EVENTO
    ============================================================ */
    public static function render_evento_detalhes_page() {

        if (!PhotoMusic_Users::current_user_can('pm_ver_eventos')) {
            wp_die('Sem permissão.');
        }

        if (empty($_GET['id'])) {
            echo '<div class="wrap"><h1>Evento não encontrado</h1></div>';
            return;
        }

        $id_evento = isset($_GET['id']) ? intval($_GET['id']) : 0;

        if ($id_evento <= 0) {
            echo '<div class="wrap"><h1>Evento não encontrado</h1></div>';
            return;
        }

        $evento = PhotoMusic_Events_Core::get_evento_completo($id_evento);

        if (!$evento) {
            echo '<div class="wrap"><h1>Evento não encontrado</h1></div>';
            return;
        }

        if (!$evento) {
            echo '<div class="wrap"><h1>Evento não encontrado</h1></div>';
            return;
        }

        echo '<div class="wrap">';
        echo '<h1>Evento #' . $evento['id'] . '</h1>';
        echo '<a class="button" href="' . admin_url('admin.php?page=photomusic-eventos') . '">← Voltar</a>';
        echo '<hr>';

        echo '<h2>Informações</h2>';
        echo '<table class="widefat striped">';
        echo '<tr><th>ID</th><td>' . $evento['id'] . '</td></tr>';
        echo '<tr><th>Motivo</th><td>' . esc_html($evento['motivo_evento']) . '</td></tr>';
        echo '<tr><th>Data</th><td>' . esc_html($evento['data_evento']) . '</td></tr>';
        echo '<tr><th>Status</th><td>' . esc_html($evento['status_evento']) . '</td></tr>';
        echo '</table>';

        echo '<hr>';

        echo '<h2>Contrato</h2>';

        $contrato = PhotoMusic_Contratos::get_by_event($id_evento);

        if ($contrato) {
            echo '<a class="button" href="' . admin_url('admin.php?page=photomusic-contrato-detalhes&id=' . $contrato->id) . '">Ver Contrato</a>';
        } else {
            echo '<p><em>Nenhum contrato criado.</em></p>';
        }

        echo '</div>';
    }

    public static function render_evento_operador_page() {

        if (!PhotoMusic_Users::current_user_can('pm_ver_eventos')) {
            wp_die('Sem permissão.');
        }

        if (empty($_GET['id'])) {
            echo '<div class="wrap"><h1>Evento não encontrado</h1></div>';
            return;
        }

        $id_evento = intval($_GET['id']);

        echo '<div class="wrap">';
        echo '<h1>Painel do Operador — Evento #' . $id_evento . '</h1>';
        echo '<a class="button" href="' . admin_url('admin.php?page=photomusic-evento-detalhes&id=' . $id_evento) . '">← Voltar</a>';
        echo '<hr>';

        // Aqui entra o HTML da tela
        include dirname(__FILE__) . '/../admin/views/evento-operador-view.php';

        echo '</div>';
    }

    /* ============================================================
        ENFILEIRAR JS DA TELA DO OPERADOR
    ============================================================ */
    public static function enqueue_scripts($hook) {

        if ($hook !== 'photomusic_page_photomusic-evento-operador') {
            return;
        }

        wp_enqueue_script(
            'pm-operador-evento',
            plugins_url('../../assets/js/pm-operador-evento.js', __FILE__),
            ['jquery'],
            '1.0',
            true
        );

        wp_localize_script('pm-operador-evento', 'PM_OPERADOR', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('pm_operador_nonce'),
        ]);
    }

}

add_action('admin_enqueue_scripts', ['PhotoMusic_Admin_Menu', 'enqueue_scripts']);

