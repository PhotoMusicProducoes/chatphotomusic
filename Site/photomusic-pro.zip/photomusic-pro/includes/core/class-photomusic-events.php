<?php
// includes/core/class-photomusic-events.php

if (!defined('ABSPATH')) exit;

class PhotoMusic_Events {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'register_menu']);
    }

    /* ============================================================
       MENU PRINCIPAL
    ============================================================ */
    public static function register_menu() {
        add_menu_page(
            'PhotoMusic Eventos',
            'PhotoMusic',
            'pm_ver_eventos',
            'photomusic-eventos',
            [__CLASS__, 'render_eventos_page'],
            'dashicons-camera',
            26
        );
    }

    /* ============================================================
       TELA PRINCIPAL — LISTAGEM DE EVENTOS
    ============================================================ */
    public static function render_eventos_page() {

        if (!PhotoMusic_Users::current_user_can('pm_ver_eventos')) {
            wp_die('Você não tem permissão para acessar esta página.');
        }

        $eventos = self::get_events();

        echo '<div class="wrap">';
        echo '<h1>Eventos PhotoMusic</h1>';

        echo '<a href="' . esc_url(add_query_arg([
            'page' => 'photomusic-eventos',
            'acao' => 'novo',
        ], admin_url('admin.php'))) . '" class="button button-primary">Criar Novo Evento</a>';

        if (empty($eventos)) {
            echo '<p style="margin-top:20px;">Nenhum evento encontrado.</p>';
            echo '</div>';
            return;
        }

        echo '<table class="widefat striped" style="margin-top:20px;">';
        echo '<thead><tr>
                <th>ID</th>
                <th>Motivo</th>
                <th>Data</th>
                <th>Contratante</th>
                <th>Tipo</th>
                <th>Status</th>
                <th>Ações</th>
            </tr></thead><tbody>';

        foreach ($eventos as $e) {

            $contratante_nome = '-';
            if (!empty($e->id_contratante)) {
                $contratante = PhotoMusic_Contratantes::get($e->id_contratante);
                if ($contratante && !is_wp_error($contratante)) {
                    $contratante_nome = $contratante->nome ?? '-';
                }
            }

            $link_editar = esc_url(add_query_arg([
                'page' => 'photomusic-eventos',
                'acao' => 'editar',
                'id'   => $e->id,
            ], admin_url('admin.php')));

            $link_operador = esc_url(add_query_arg([
                'page' => 'photomusic-eventos',
                'acao' => 'operador',
                'id'   => $e->id,
            ], admin_url('admin.php')));

            $link_contrato = esc_url(add_query_arg([
                'page' => 'photomusic-eventos',
                'acao' => 'contrato',
                'id'   => $e->id,
            ], admin_url('admin.php')));

            echo '<tr>';
            echo '<td>' . intval($e->id) . '</td>';
            echo '<td>' . esc_html($e->motivo_evento) . '</td>';
            echo '<td>' . esc_html($e->data_evento) . '</td>';
            echo '<td>' . esc_html($contratante_nome) . '</td>';
            echo '<td>' . esc_html($e->tipo_evento) . '</td>';
            echo '<td>' . esc_html($e->status_evento) . '</td>';
            echo '<td>
                    <a href="' . $link_editar . '" class="button">Editar</a>
                    <a href="' . $link_operador . '" class="button">Operador</a>
                    <a href="' . $link_contrato . '" class="button">Contrato</a>
                </td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }

    /* ============================================================
       CRIAR EVENTO PF/PJ
    ============================================================ */
    public static function create_event($data) {
        global $wpdb;

        $table = $wpdb->prefix . 'pm_eventos';

        // Tipo do evento
        $tipo_evento = strtoupper(trim($data['tipo_evento'] ?? ''));
        if (!in_array($tipo_evento, ['PF', 'PJ'], true)) {
            return new WP_Error('tipo_evento_invalido', 'Tipo de evento inválido.');
        }

        // Motivo
        if (empty($data['motivo_evento'])) {
            return new WP_Error('motivo_obrigatorio', 'O motivo do evento é obrigatório.');
        }
        $motivo = substr(sanitize_text_field($data['motivo_evento']), 0, 200);

        // Data do evento
        $data_evento = sanitize_text_field($data['data_evento'] ?? '');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data_evento)) {
            return new WP_Error('data_evento_invalida', 'A data do evento é inválida. Use o formato YYYY-MM-DD.');
        }

        // Criar contratante PF/PJ
        $id_contratante = ($tipo_evento === 'PF')
            ? PhotoMusic_Contratantes::create_pf($data)
            : PhotoMusic_Contratantes::create_pj($data);

        if (is_wp_error($id_contratante)) {
            return $id_contratante;
        }

        if (!$id_contratante) {
            return new WP_Error('erro_contratante', 'Não foi possível criar o contratante.');
        }

        // Criar evento
        $wpdb->insert($table, [
            'tipo_evento'    => $tipo_evento,
            'motivo_evento'  => $motivo,
            'data_evento'    => $data_evento,
            'codigo_interno' => PhotoMusic_Helpers::generate_code('EVT'),
            'id_contratante' => $id_contratante,
            'status_evento'  => 'ativo',
            'criado_por'     => get_current_user_id(),
            'criado_em'      => current_time('mysql'),
        ]);

        $id_evento = $wpdb->insert_id;

        if (!$id_evento) {
            return new WP_Error('erro_criar_evento', 'Não foi possível criar o evento.');
        }

        // Criar contrato rascunho
        PhotoMusic_Contratos::criar_contrato_simplificado($id_evento, $id_contratante);

        // Registrar histórico
        PhotoMusic_Events::registrar_historico($id_evento, 'Evento criado.');

        return $id_evento;
    }

    /* ============================================================
       ATUALIZAR EVENTO
    ============================================================ */
    public static function update_event($id_evento, $data) {
        global $wpdb;

        $table = $wpdb->prefix . 'pm_eventos';
        $id_evento = (int) $id_evento;

        if ($id_evento <= 0) {
            return new WP_Error('id_invalido', 'ID inválido.');
        }

        $update = [];

        if (isset($data['motivo_evento'])) {
            $update['motivo_evento'] = substr(sanitize_text_field($data['motivo_evento']), 0, 200);
        }

        if (isset($data['data_evento'])) {
            $data_evento = sanitize_text_field($data['data_evento']);
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data_evento)) {
                return new WP_Error('data_evento_invalida', 'A data do evento é inválida. Use o formato YYYY-MM-DD.');
            }
            $update['data_evento'] = $data_evento;
        }

        if (isset($data['status_evento'])) {
            $update['status_evento'] = sanitize_text_field($data['status_evento']);
        }

        if (!empty($update)) {
            $update['atualizado_em'] = current_time('mysql');
            $wpdb->update($table, $update, ['id' => $id_evento]);
        }

        // Atualizar contratante
        if (!empty($data['contratante']) && !empty($data['contratante']['id'])) {

            $contratante = PhotoMusic_Contratantes::get($data['contratante']['id']);

            if (!$contratante) {
                return new WP_Error('contratante_inexistente', 'Contratante não encontrado.');
            }

            if ($contratante->tipo === 'PF') {
                $result = PhotoMusic_Contratantes::update_pf($contratante->id, $data['contratante']);
            } else {
                $result = PhotoMusic_Contratantes::update_pj($contratante->id, $data['contratante']);
            }

            if (is_wp_error($result)) {
                return $result;
            }
        }

        PhotoMusic_Events::registrar_historico($id_evento, 'Evento atualizado.');

        return true;
    }

    /* ============================================================
       LISTAR EVENTOS
    ============================================================ */
    public static function get_events($args = []) {
        global $wpdb;

        $table = $wpdb->prefix . 'pm_eventos';

        $where = ['1=1'];
        $params = [];

        if (!empty($args['status_evento'])) {
            $where[] = 'status_evento = %s';
            $params[] = sanitize_text_field($args['status_evento']);
        }

        if (!empty($args['tipo_evento'])) {
            $where[] = 'tipo_evento = %s';
            $params[] = sanitize_text_field($args['tipo_evento']);
        }

        $sql = "SELECT * FROM $table WHERE " . implode(' AND ', $where) . " ORDER BY data_evento DESC, id DESC";

        return !empty($params)
            ? $wpdb->get_results($wpdb->prepare($sql, ...$params))
            : $wpdb->get_results($sql);
    }

    /* ============================================================
       BUSCAR EVENTO POR ID       ← ADICIONAR ESTE BLOCO INTEIRO
    ============================================================ */
    public static function get_event($id_evento) {
        global $wpdb;
        $tbl = $wpdb->prefix . 'pm_eventos';
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $tbl WHERE id = %d",
            intval($id_evento)
        ));
    }

    /* ============================================================
       WRAPPERS PARA O CORE
    ============================================================ */
    public static function update_status($id_evento, $status) {
        $core = new PhotoMusic_Events_Core();
        return $core->update_status($id_evento, $status);
    }

    public static function registrar_historico($id_evento, $acao, $detalhes = null) {
        $core = new PhotoMusic_Events_Core();
        return $core->registrar_historico($id_evento, $acao, $detalhes);
    }
}
