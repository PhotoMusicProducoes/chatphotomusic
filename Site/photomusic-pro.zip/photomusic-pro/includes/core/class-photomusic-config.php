<?php
// includes/core/class-photomusic-config.php

if (!defined('ABSPATH')) exit;

class PhotoMusic_Config {

    public static function init() {
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_post_pm_salvar_config', [__CLASS__, 'salvar']);
    }

    /* ============================================================
       REGISTRA AS CONFIGURAÇÕES
    ============================================================ */
    public static function register_settings() {
        register_setting('pm_config_group', 'photomusic_contrato_page', [
            'type'              => 'integer',
            'sanitize_callback' => 'intval',
            'default'           => 0,
        ]);
    }

    /* ============================================================
       PROCESSA O FORMULÁRIO (admin-post)
    ============================================================ */
    public static function salvar() {

        if (!current_user_can('manage_options')) {
            wp_die('Sem permissão.');
        }

        check_admin_referer('pm_salvar_config');

        $page_id = intval($_POST['photomusic_contrato_page'] ?? 0);
        update_option('photomusic_contrato_page', $page_id);

        wp_redirect(add_query_arg([
            'page'    => 'photomusic-config',
            'saved'   => 1,
        ], admin_url('admin.php')));
        exit;
    }

    /* ============================================================
       RENDERIZA A PÁGINA DE CONFIGURAÇÕES
    ============================================================ */
    public static function render_page() {

        if (!current_user_can('manage_options')) {
            wp_die('Acesso negado.');
        }

        // ID salvo atualmente
        $pagina_contrato_id = (int) get_option('photomusic_contrato_page', 0);

        // Busca todas as páginas publicadas para o select
        $paginas = get_pages(['post_status' => 'publish', 'sort_column' => 'post_title']);

        // Verifica se a página salva existe
        $pagina_salva = $pagina_contrato_id ? get_post($pagina_contrato_id) : null;
        $url_publica  = $pagina_salva ? get_permalink($pagina_salva) : '';
        ?>

        <div class="wrap">
            <h1>Configurações — PhotoMusic Pro</h1>

            <?php if (!empty($_GET['saved'])): ?>
                <div class="notice notice-success is-dismissible">
                    <p><strong>Configurações salvas com sucesso.</strong></p>
                </div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('pm_salvar_config'); ?>
                <input type="hidden" name="action" value="pm_salvar_config">

                <table class="form-table">

                    <!-- ============================================
                         PÁGINA DE ASSINATURA DE CONTRATO
                    ============================================ -->
                    <tr>
                        <th scope="row">
                            <label for="photomusic_contrato_page">
                                Página de Assinatura de Contrato
                            </label>
                        </th>
                        <td>
                            <select name="photomusic_contrato_page"
                                    id="photomusic_contrato_page"
                                    style="min-width: 300px;">

                                <option value="0">— Selecione uma página —</option>

                                <?php foreach ($paginas as $pagina): ?>
                                    <option value="<?php echo esc_attr($pagina->ID); ?>"
                                        <?php selected($pagina_contrato_id, $pagina->ID); ?>>
                                        <?php echo esc_html($pagina->post_title); ?>
                                        (ID: <?php echo esc_html($pagina->ID); ?>)
                                    </option>
                                <?php endforeach; ?>

                            </select>

                            <?php if ($pagina_salva && $url_publica): ?>
                                <p class="description">
                                    ✅ Página configurada:
                                    <a href="<?php echo esc_url($url_publica); ?>" target="_blank">
                                        <?php echo esc_html($url_publica); ?>
                                    </a>
                                </p>
                            <?php else: ?>
                                <p class="description" style="color: #b32d2e;">
                                    ⚠️ Nenhuma página configurada. Os links de contrato vão
                                    retornar erro 404 até isso ser definido.
                                </p>
                            <?php endif; ?>

                            <p class="description">
                                Selecione a página que contém o shortcode
                                <code>[photomusic_contrato]</code>.
                                Todos os links <code>/contrato/{token}/</code>
                                gerados no PDF e no WhatsApp vão redirecionar para ela.
                            </p>
                        </td>
                    </tr>

                </table>

                <?php submit_button('Salvar Configurações'); ?>

            </form>

            <!-- ============================================
                 INFORMAÇÃO EXTRA: ID ATUAL
            ============================================ -->
            <?php if ($pagina_contrato_id > 0): ?>
                <hr>
                <h3>Informação técnica</h3>
                <table class="widefat" style="max-width: 500px;">
                    <tr>
                        <th>Opção no banco</th>
                        <td><code>photomusic_contrato_page</code></td>
                    </tr>
                    <tr>
                        <th>ID salvo</th>
                        <td><strong><?php echo esc_html($pagina_contrato_id); ?></strong></td>
                    </tr>
                    <tr>
                        <th>Título da página</th>
                        <td><?php echo $pagina_salva ? esc_html($pagina_salva->post_title) : '<em style="color:#b32d2e;">Página não encontrada</em>'; ?></td>
                    </tr>
                    <tr>
                        <th>URL pública</th>
                        <td>
                            <?php if ($url_publica): ?>
                                <a href="<?php echo esc_url($url_publica); ?>" target="_blank">
                                    <?php echo esc_html($url_publica); ?>
                                </a>
                            <?php else: ?>
                                <em style="color:#b32d2e;">URL não disponível</em>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            <?php endif; ?>

        </div>

        <?php
    }
}