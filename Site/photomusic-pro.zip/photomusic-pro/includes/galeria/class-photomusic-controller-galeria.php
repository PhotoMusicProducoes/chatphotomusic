<?php
// includes/galeria/class-photomusic-controller-galeria.php

if (!defined('ABSPATH')) exit;

class PhotoMusic_Galeria_Controller {

    private $wpdb;
    private $tbl_eventos;
    private $tbl_aceites_evento;
    private $tbl_devices;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;

        $this->tbl_eventos        = $wpdb->prefix . 'pm_eventos';
        $this->tbl_aceites_evento = $wpdb->prefix . 'pm_aceites_evento';
        $this->tbl_devices        = $wpdb->prefix . 'pm_devices';
    }

    /* ============================================================
       PONTO DE ENTRADA DA GALERIA
    ============================================================ */
    public function handle_request() {

        // Correção: o nome correto da query var é "evento_slug"
        $slug  = sanitize_text_field(get_query_var('evento_slug'));
        $token = sanitize_text_field($_GET['token'] ?? '');

        if (!$slug || !$token) {
            wp_die('Acesso inválido.');
        }

        /* ============================================================
           VALIDAR TOKEN
        ============================================================ */
        if (!PhotoMusic_Helpers::is_valid_sha256($token)) {
            wp_die('Token inválido.');
        }

        /* ============================================================
           BUSCAR EVENTO PELO SLUG
        ============================================================ */
        $evento = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->tbl_eventos} WHERE codigo_interno = %s",
            $slug
        ));

        if (!$evento) {
            wp_die('Evento não encontrado.');
        }

        /* ============================================================
           VALIDAR ACEITE PELO TOKEN
        ============================================================ */
        $aceite = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM {$this->tbl_aceites_evento}
             WHERE id_evento = %d
             AND SHA2(CONCAT(id_evento, '|', id, '|', UNIX_TIMESTAMP(aceite_em), '|', versao_termo), 256) = %s",
            $evento->id,
            $token
        ));

        if (!$aceite) {
            wp_die('Seu acesso expirou ou é inválido.');
        }

        /* ============================================================
           VALIDAR DEVICE
        ============================================================ */
        $device_hash = PhotoMusic_Helpers::device_hash();

        if (!empty($aceite->device_hash) && $device_hash !== $aceite->device_hash) {
            wp_die('Este link não pertence a este dispositivo.');
        }

        /* ============================================================
           REGISTRAR LOG DE ACESSO
        ============================================================ */
        $this->registrar_acesso($evento->id, $aceite->id);

        /* ============================================================
           CARREGAR TEMPLATE DA GALERIA
        ============================================================ */
        $this->render_template($evento, $aceite);
    }

    /* ============================================================
       REGISTRA ACESSO
    ============================================================ */
    private function registrar_acesso($id_evento, $id_aceite) {

        $ip         = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '');
        $user_agent = sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? '');

        $this->wpdb->insert($this->wpdb->prefix . 'pm_logs', [
            'id_evento'  => $id_evento,
            'id_aceite'  => $id_aceite,
            'tipo'       => 'acesso_galeria',
            'ip'         => $ip,
            'user_agent' => $user_agent,
            'data'       => current_time('mysql')
        ]);
    }

    /* ============================================================
       RENDERIZA O TEMPLATE DA GALERIA
    ============================================================ */
    private function render_template($evento, $aceite) {

        $template = PHOTOMUSIC_PRO_PATH . 'includes/galeria/templates/galeria.php';

        if (!file_exists($template)) {
            wp_die('Template da galeria não encontrado.');
        }

        // Variáveis disponíveis no template:
        $evento_nome = $evento->nome_evento;
        $evento_data = $evento->data_evento;
        $slug        = $evento->codigo_interno;
        $id_evento   = $evento->id;
        $id_aceite   = $aceite->id;

        include $template;
    }
}
