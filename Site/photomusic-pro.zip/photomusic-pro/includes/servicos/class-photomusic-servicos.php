<?php
// includes/servicos/class-photomusic-servicos.php

if (!defined('ABSPATH')) exit;

class PhotoMusic_Servicos {

    private static $tbl_servicos;
    private static $tbl_subtipos;
    private static $tbl_pacotes;
    private static $tbl_regras;
    private static $tbl_eventos_servicos;

    public static function init() {
        global $wpdb;

        self::$tbl_servicos         = $wpdb->prefix . 'pm_servicos';
        self::$tbl_subtipos         = $wpdb->prefix . 'pm_servicos_subtipos';
        self::$tbl_pacotes          = $wpdb->prefix . 'pm_servicos_pacotes';
        self::$tbl_regras           = $wpdb->prefix . 'pm_servicos_regras';
        self::$tbl_eventos_servicos = $wpdb->prefix . 'pm_eventos_servicos';
    }

    /* ============================================================
       CATÁLOGO DE SERVIÇOS
    ============================================================ */

    public static function listar_servicos($apenas_ativos = true) {
        global $wpdb;

        $sql = "SELECT * FROM " . self::$tbl_servicos;

        if ($apenas_ativos) {
            $sql .= " WHERE ativo = 1";
        }

        $sql .= " ORDER BY ordem ASC, nome ASC";

        return $wpdb->get_results($sql, ARRAY_A);
    }

    public static function get_servico($id) {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM " . self::$tbl_servicos . " WHERE id = %d", $id),
            ARRAY_A
        );
    }

    /* ============================================================
       SUBTIPOS
    ============================================================ */

    public static function listar_subtipos($id_servico) {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM " . self::$tbl_subtipos . " 
                 WHERE id_servico = %d AND ativo = 1 
                 ORDER BY ordem ASC",
                $id_servico
            ),
            ARRAY_A
        );
    }

    public static function get_subtipo($id) {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM " . self::$tbl_subtipos . " WHERE id = %d", $id),
            ARRAY_A
        );
    }

    /* ============================================================
       PACOTES
    ============================================================ */

    public static function listar_pacotes($id_servico, $id_subtipo = null) {
        global $wpdb;

        $sql = "SELECT * FROM " . self::$tbl_pacotes . " WHERE id_servico = %d AND ativo = 1";
        $params = [$id_servico];

        if (!empty($id_subtipo)) {
            $sql .= " AND id_subtipo = %d";
            $params[] = $id_subtipo;
        }

        $sql .= " ORDER BY ordem ASC";

        return $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
    }

    public static function get_pacote($id) {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM " . self::$tbl_pacotes . " WHERE id = %d", $id),
            ARRAY_A
        );
    }

    /* ============================================================
       REGRAS POR CELEBRAÇÃO
    ============================================================ */
    public static function get_regras_por_celebracao($id_servico, $celebracao) {
        global $wpdb;

        // 🔥 SANITIZAÇÃO NOVA
        $celebracao = sanitize_text_field($celebracao);

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM " . self::$tbl_regras . " 
                WHERE id_servico = %d AND celebracao = %s AND ativo = 1",
                $id_servico,
                $celebracao
                ),
                ARRAY_A
        );
    }

    /* ============================================================
       CÁLCULO DE HORAS PERMITIDAS
    ============================================================ */

    public static function calcular_horas_permitidas($id_servico, $celebracao) {

        $regras = self::get_regras_por_celebracao($id_servico, $celebracao);

        if (!$regras) {
            return [
                'min' => 1,
                'max' => 12
            ];
        }

        return [
            'min' => intval($regras['horas_min'] ?? 1),
            'max' => intval($regras['horas_max'] ?? 12)
        ];
    }

    /* ============================================================
       SALVAR SERVIÇOS CONTRATADOS DO EVENTO
    ============================================================ */

    public static function salvar_evento_servicos($id_evento, $servicos) {
        global $wpdb;

        $wpdb->delete(self::$tbl_eventos_servicos, ['id_evento' => $id_evento]);

        foreach ($servicos as $s) {

            $id_servico  = intval($s['id_servico'] ?? 0);

            // 🔥 VALIDAÇÃO NOVA
            $servico = self::get_servico($id_servico);
            if (!$servico) continue;

            $id_subtipo  = intval($s['id_subtipo'] ?? 0);
            $id_pacote   = intval($s['id_pacote'] ?? 0);

            $horas       = intval($s['horas'] ?? 0);
            $fotos       = intval($s['fotos'] ?? 0);

            $valor_base      = floatval($s['valor_base'] ?? 0);
            $valor_adicional = floatval($s['valor_adicional'] ?? 0);
            $valor_final     = floatval($s['valor_final'] ?? 0);

            $obs = sanitize_textarea_field($s['obs'] ?? '');
            $obs = substr($obs, 0, 2000);

            $wpdb->insert(self::$tbl_eventos_servicos, [
                'id_evento'         => $id_evento,
                'id_servico'        => $id_servico,
                'id_subtipo'        => $id_subtipo,
                'id_pacote'         => $id_pacote,
                'horas_contratadas' => $horas,
                'fotos_contratadas' => $fotos,
                'valor_base'        => $valor_base,
                'valor_adicional'   => $valor_adicional,
                'valor_final'       => $valor_final,
                'observacoes'       => $obs
            ]);
        }

        // Depois do foreach
        if (class_exists('PhotoMusic_Logs')) {
            PhotoMusic_Logs::add(
                'evento_servicos_atualizados',
                null,
                $id_evento,
                null,
                'Serviços do evento atualizados.'
            );
        }

    }

    /* ============================================================
       LISTAR SERVIÇOS CONTRATADOS DO EVENTO
    ============================================================ */

    public static function get_evento_servicos($id_evento) {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM " . self::$tbl_eventos_servicos . " 
                 WHERE id_evento = %d ORDER BY id ASC",
                $id_evento
            ),
            ARRAY_A
        );
    }
}
